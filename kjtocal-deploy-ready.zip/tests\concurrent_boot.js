"use strict";
/** Regression: several processes booting at the same instant on an empty instance must not crash,
 * double-seed, or end up with different session-signing keys. Uses IPC (not stdout) for the worker's
 * result, since the app's own startup logging shares the stdout stream. Mirrors tests/concurrent_boot.py. */
const { fork } = require("child_process");
const fs = require("fs");
const os = require("os");
const path = require("path");
const Database = require("better-sqlite3");

const inst = fs.mkdtempSync(path.join(os.tmpdir(), "kjboot-"));
const workerPath = path.join(__dirname, "_boot_worker.js");

function runWorker() {
  return new Promise((resolve) => {
    const child = fork(workerPath, [], {
      env: Object.assign({}, process.env, { KJ_ENV: "development", ADMIN_PASSWORD: "test-password-123", KJ_INSTANCE: inst }),
      silent: true,
    });
    let msg = null;
    child.on("message", (m) => { msg = m; });
    child.on("exit", (code) => resolve({ code, msg }));
  });
}

async function main() {
  const results = await Promise.all(Array.from({ length: 6 }, runWorker));
  const errors = results.filter((r) => r.code !== 0 || !r.msg || !r.msg.ok);
  const secrets = new Set(results.map((r) => (r.msg && r.msg.secret) || ""));
  const db = new Database(path.join(inst, "kjtocal.db"), { readonly: true });
  const pages = db.prepare("SELECT COUNT(*) c FROM pages").get().c;
  const users = db.prepare("SELECT COUNT(*) c FROM users").get().c;
  const values = db.prepare("SELECT COUNT(*) c FROM convert_values").get().c;
  console.log("errors:", errors.length ? errors.map((e) => e.msg && e.msg.error) : "none",
    "| distinct secret keys:", secrets.size, "| pages:", pages, "users:", users, "values:", values);
  const good = !errors.length && secrets.size === 1 && pages === 24 && users === 1 && values === 35;
  console.log(good ? "CONCURRENT BOOT OK" : "CONCURRENT BOOT FAILED");
  process.exit(good ? 0 : 1);
}

main();
