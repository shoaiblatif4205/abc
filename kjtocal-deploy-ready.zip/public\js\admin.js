/* KJ to Cal admin — vanilla JS */
(function () {
  'use strict';
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var token = (document.querySelector('input[name=_csrf]') || {}).value || '';

  // mobile menu
  var mb = $('[data-menu]');
  if (mb) mb.addEventListener('click', function () { var s = $('#side'); var o = s.classList.toggle('open'); mb.setAttribute('aria-expanded', o); });

  // confirm dialogs
  $$('form[data-confirm]').forEach(function (f) { f.addEventListener('submit', function (e) { if (!confirm(f.getAttribute('data-confirm'))) e.preventDefault(); }); });
  $$('form[data-confirm-bulk]').forEach(function (f) {
    f.addEventListener('submit', function (e) {
      var a = f.querySelector('[name=action]').value;
      if (a === 'delete' && !confirm('Delete the selected pages permanently?')) e.preventDefault();
    });
  });
  $$('[data-all]').forEach(function (a) { a.addEventListener('change', function () { $$('input[name=ids]').forEach(function (c) { c.checked = a.checked; }); }); });
  $$('[data-select]').forEach(function (c) { c.addEventListener('click', function () { var r = document.createRange(); r.selectNodeContents(c); var s = getSelection(); s.removeAllRanges(); s.addRange(r); }); });

  // unsaved changes guard
  $$('form[data-dirty-guard]').forEach(function (f) {
    var dirty = false;
    f.addEventListener('input', function () { dirty = true; });
    f.addEventListener('submit', function () { dirty = false; });
    window.addEventListener('beforeunload', function (e) { if (dirty) { e.preventDefault(); e.returnValue = ''; } });
  });

  // tabs
  var tabs = $$('[data-tab]');
  function showTab(name) {
    tabs.forEach(function (t) { t.setAttribute('aria-selected', t.getAttribute('data-tab') === name ? 'true' : 'false'); });
    $$('[data-panel]').forEach(function (p) { p.hidden = p.getAttribute('data-panel') !== name; });
    if (history.replaceState) history.replaceState(null, '', '#' + name);
  }
  if (tabs.length) {
    tabs.forEach(function (t) { t.addEventListener('click', function () { showTab(t.getAttribute('data-tab')); }); });
    var h = location.hash.replace('#', '');
    if (h && tabs.some(function (t) { return t.getAttribute('data-tab') === h; })) showTab(h);
  }

  // counters
  $$('[data-count]').forEach(function (el) {
    var max = parseInt(el.getAttribute('data-count'), 10);
    var out = document.querySelector('[data-count-for="' + el.id + '"]');
    function upd() { var n = el.value.length; out.textContent = n + ' / ' + max; out.className = 'count' + (n > max ? ' over' : (n >= max * 0.6 ? ' good' : '')); }
    el.addEventListener('input', upd); upd();
  });

  // SERP preview + slug
  var title = $('[data-title]'), path = $('[data-path]'), seoT = $('#f-seo_title'), seoD = $('#f-meta_description');
  function serp() {
    var t = $('[data-serp-title]'); if (!t) return;
    t.textContent = (seoT && seoT.value) || (title && title.value) || '';
    $('[data-serp-desc]').textContent = seoD ? seoD.value : '';
    $('[data-serp-url]').textContent = 'https://kjtocal.org' + (path ? path.value : '');
  }
  [title, path, seoT, seoD].forEach(function (e) { if (e) e.addEventListener('input', serp); });
  if (title && path && !path.readOnly && (path.value === '/' || path.value === '')) {
    var touched = false;
    path.addEventListener('input', function () { touched = true; });
    title.addEventListener('input', function () {
      if (touched) return;
      var s = title.value.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
      path.value = s ? '/' + s + '/' : '/';
      serp();
    });
  }

  // schedule field
  var st = $('[data-status]'), sch = $('[data-schedule]');
  if (st && sch) st.addEventListener('change', function () { sch.hidden = st.value !== 'scheduled'; });

  // FAQ repeater
  var fl = $('[data-faq-list]'), ft = $('#faq-tpl');
  if (fl && ft) {
    $('[data-faq-add]').addEventListener('click', function () { fl.appendChild(ft.content.cloneNode(true)); var i = fl.querySelectorAll('input[name=faq_q]'); i[i.length - 1].focus(); });
    fl.addEventListener('click', function (e) { if (e.target.hasAttribute('data-faq-remove')) { e.target.closest('.faq-row').remove(); document.getElementById('page-form').dispatchEvent(new Event('input')); } });
  }

  // Markdown editor
  var ta = $('#f-content_md');
  if (ta) {
    function wrap(before, after, placeholder) {
      var s = ta.selectionStart, e = ta.selectionEnd, sel = ta.value.slice(s, e) || placeholder || '';
      ta.setRangeText(before + sel + after, s, e, 'end');
      ta.focus(); ta.setSelectionRange(s + before.length, s + before.length + sel.length);
      ta.dispatchEvent(new Event('input', { bubbles: true }));
    }
    function lines(prefixFn) {
      var s = ta.selectionStart, e = ta.selectionEnd, v = ta.value;
      var a = v.lastIndexOf('\n', s - 1) + 1, b = v.indexOf('\n', e); if (b < 0) b = v.length;
      var block = v.slice(a, b).split('\n').map(prefixFn).join('\n');
      ta.setRangeText(block, a, b, 'end'); ta.focus(); ta.dispatchEvent(new Event('input', { bubbles: true }));
    }
    var actions = {
      bold: function () { wrap('**', '**', 'bold text'); },
      italic: function () { wrap('*', '*', 'italic text'); },
      h2: function () { lines(function (l) { return '## ' + l.replace(/^#+\s*/, ''); }); },
      h3: function () { lines(function (l) { return '### ' + l.replace(/^#+\s*/, ''); }); },
      ul: function () { lines(function (l) { return '- ' + l.replace(/^[-*]\s+/, ''); }); },
      ol: function () { var n = 0; lines(function (l) { n++; return n + '. ' + l.replace(/^\d+\.\s+/, ''); }); },
      link: function () { var u = prompt('Link URL (e.g. /calories-to-kj/ or https://…)'); if (u) wrap('[', '](' + u + ')', 'link text'); },
      table: function () { wrap('\n| Column A | Column B |\n|---|---|\n| Value | Value |\n', '', ''); },
      answer: function () { wrap('\n!!! answer "Quick answer"\n    ', '\n', 'Write the direct answer here.'); },
      chart: function () { wrap('\n[[chart]]\n', '', ''); },
      image: function () { openPicker(function (m) { wrap('![' + (m.alt || 'Describe the image') + '](' + m.url + ')', '', ''); }); }
    };
    $$('[data-md]').forEach(function (b) { b.addEventListener('click', function () { actions[b.getAttribute('data-md')](); }); });
    ta.addEventListener('keydown', function (e) {
      if ((e.ctrlKey || e.metaKey) && e.key === 'b') { e.preventDefault(); actions.bold(); }
      if ((e.ctrlKey || e.metaKey) && e.key === 'i') { e.preventDefault(); actions.italic(); }
    });
    var ed = $('[data-editor]'), pv = $('[data-preview]'), tgl = $('[data-preview-toggle]'), timer;
    function refresh() {
      fetch('/admin/api/preview', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': token }, body: JSON.stringify({ md: ta.value }) })
        .then(function (r) { return r.json(); }).then(function (j) { pv.innerHTML = j.html; }).catch(function () { pv.textContent = 'Preview unavailable.'; });
    }
    tgl.addEventListener('click', function () {
      var on = pv.hidden; pv.hidden = !on; ed.classList.toggle('split', on); tgl.textContent = on ? 'Hide preview' : 'Preview'; if (on) refresh();
    });
    ta.addEventListener('input', function () { if (!pv.hidden) { clearTimeout(timer); timer = setTimeout(refresh, 350); } });
  }

  // Media picker
  var modal = $('[data-media-modal]'), pickCb = null;
  function openPicker(cb) {
    if (!modal) return;
    pickCb = cb; modal.hidden = false;
    var grid = $('[data-media-grid]'); grid.textContent = 'Loading…';
    fetch('/admin/media/json').then(function (r) { return r.json(); }).then(function (items) {
      grid.textContent = '';
      if (!items.length) { grid.textContent = 'No images uploaded yet.'; return; }
      items.forEach(function (m) {
        var b = document.createElement('button'); b.type = 'button'; b.title = m.name;
        var i = document.createElement('img'); i.src = m.url; i.alt = m.alt || m.name; b.appendChild(i);
        b.addEventListener('click', function () { modal.hidden = true; pickCb && pickCb(m); });
        grid.appendChild(b);
      });
    });
  }
  if (modal) {
    $('[data-modal-close]').addEventListener('click', function () { modal.hidden = true; });
    modal.addEventListener('click', function (e) { if (e.target === modal) modal.hidden = true; });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') modal.hidden = true; });
    $$('[data-pick-image]').forEach(function (b) { b.addEventListener('click', function () { var t = document.getElementById(b.getAttribute('data-pick-image')); openPicker(function (m) { t.value = m.url; t.dispatchEvent(new Event('input', { bubbles: true })); }); }); });
  }
})();
