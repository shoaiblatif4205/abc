"use strict";
/** kjtocal.org - Express application (public site + admin mount). Mirrors app.py. */
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const express = require("express");
const session = require("express-session");
const SqliteStoreFactory = require("better-sqlite3-session-store");

const D = require("./src/lib/db");
const CT = require("./src/lib/content");
const core = require("./src/lib/core");
const auth = require("./src/lib/auth");
const seed = require("./src/lib/seed");
const storage = require("./src/lib/storage");
const { SEED_FALLBACK_KJ_CHART, SEED_FALLBACK_CAL_CHART } = (() => {
  const raw = require("./src/data/seed-content.json");
  const dec = (groups) => groups.map(([t, vals]) => [t, vals.map(Number)]);
  return { SEED_FALLBACK_KJ_CHART: dec(raw.kjChart), SEED_FALLBACK_CAL_CHART: dec(raw.calChart) };
})();

function loadDotenv() {
  const p = path.join(__dirname, ".env");
  if (!fs.existsSync(p)) return;
  for (const line of fs.readFileSync(p, "utf8").split("\n")) {
    const t = line.trim();
    if (!t || t.startsWith("#") || !t.includes("=")) continue;
    const i = t.indexOf("=");
    const k = t.slice(0, i).trim();
    let v = t.slice(i + 1).trim().replace(/^['"]|['"]$/g, "");
    if (v && process.env[k] === undefined) process.env[k] = v;
  }
}

/** Atomically create/read the persistent signing key so every worker/process shares one. */
function loadSecret(secretPath) {
  for (let i = 0; i < 100; i++) {
    try {
      const fd = fs.openSync(secretPath, "wx", 0o600);
      fs.writeSync(fd, crypto.randomBytes(32).toString("hex"));
      fs.closeSync(fd);
    } catch (_) { /* another process already created it, or a race - just re-read below */ }
    try {
      const v = fs.readFileSync(secretPath, "utf8").trim();
      if (v.length >= 64) return v;
    } catch (_) { /* not written yet */ }
  }
  throw new Error("Could not read or create " + secretPath);
}

function bootstrapAdmin(db, instanceDir) {
  // Same IMMEDIATE-transaction guard as seed.run(): serialises the "any users yet?" check
  // against the insert across concurrently-booting processes.
  const tx = db.transaction(() => {
    const n = db.prepare("SELECT COUNT(*) c FROM users").get().c;
    if (n !== 0) return null;
    const username = process.env.ADMIN_USERNAME || "admin";
    let pw = process.env.ADMIN_PASSWORD;
    const generated = !pw;
    if (!pw) pw = crypto.randomBytes(9).toString("base64url");
    db.prepare("INSERT INTO users(username,email,password_hash,role,must_change_pw,created_at) VALUES(?,?,?,?,?,?)").run(
      username, "", auth.hashPw(pw), "admin", generated ? 1 : 0, D.now()
    );
    return { username, pw, generated };
  });
  const result = tx.immediate();
  if (result && result.generated) {
    const p = path.join(instanceDir, "first-run-admin.txt");
    fs.writeFileSync(p, `username: ${result.username}\npassword: ${result.pw}\n(You must change this password at first login. Delete this file afterwards.)\n`, { mode: 0o600 });
    // eslint-disable-next-line no-console
    console.log(`\n=== KJ to Cal admin created ===\n  username: ${result.username}\n  password: ${result.pw}\n  (also saved to ${p})\n`);
  }
}

function resolveInstanceDir() {
  return process.env.KJ_INSTANCE || path.join(__dirname, "instance");
}

/**
 * Optional pre-boot step for hosts with ephemeral local disk (see src/lib/storage.js): if
 * S3_* is configured and the database/secret key aren't on local disk (e.g. a Hostinger Business
 * "Web App" redeploy wiped the filesystem), pull the last backup down before createApp() opens
 * the database. A no-op, and safe to skip, when object storage isn't configured.
 */
async function restoreFromObjectStorageIfNeeded(testConfig) {
  if (!storage.enabled()) return;
  const instanceDir = resolveInstanceDir();
  fs.mkdirSync(instanceDir, { recursive: true });
  const dbPath = (testConfig && testConfig.DATABASE) || path.join(instanceDir, "kjtocal.db");
  const secretPath = path.join(instanceDir, "secret.key");
  if (await storage.restoreDatabaseIfMissing(dbPath)) {
    console.log("Restored database from object storage backup (local copy was missing).");
  }
  if (await storage.restoreFileIfMissing(secretPath, "secret.key")) {
    console.log("Restored session signing key from object storage backup.");
  }
}

function createApp(testConfig) {
  loadDotenv();
  const env = process.env.KJ_ENV || "production";
  const instanceDir = resolveInstanceDir();
  fs.mkdirSync(instanceDir, { recursive: true });
  const uploadDir = (testConfig && testConfig.UPLOAD_DIR) || path.join(instanceDir, "uploads");
  fs.mkdirSync(uploadDir, { recursive: true });
  const dbPath = (testConfig && testConfig.DATABASE) || path.join(instanceDir, "kjtocal.db");

  const secretPath = path.join(instanceDir, "secret.key");
  const secret = process.env.SECRET_KEY || loadSecret(secretPath);
  if (storage.enabled()) storage.backupFileOnce(secretPath, "secret.key").catch(() => {});

  const db = D.openDb(dbPath);
  D.initSchema(db);
  const seeded = seed.run(db);
  if (seeded && env === "development") console.log("Seeded database with initial content.");
  bootstrapAdmin(db, instanceDir);

  if (storage.enabled() && !(testConfig && testConfig.TESTING)) {
    const mins = parseInt(process.env.S3_BACKUP_INTERVAL_MINUTES || "10", 10);
    storage.startAutoBackup(db, mins, (msg) => console.log(msg));
    // Also take one backup shortly after boot, so a fresh deploy has a snapshot immediately
    // rather than waiting a full interval (cheap: one `.backup()` + one small upload).
    setTimeout(() => storage.backupDatabase(db).catch(() => {}), 10000).unref();
  }

  const app = express();
  app.set("view engine", "ejs");
  app.set("views", path.join(__dirname, "views"));
  app.locals.core = core;
  app.locals.CT = CT;
  app.locals.testing = !!(testConfig && testConfig.TESTING);
  app.set("trust proxy", parseInt(process.env.TRUSTED_PROXIES || "0", 10));

  app.use(express.urlencoded({ extended: false, limit: "6mb" }));
  app.use(express.json({ limit: "1mb" }));
  app.use("/img", express.static(path.join(__dirname, "public", "img"), { maxAge: "30d" }));
  app.use("/css", express.static(path.join(__dirname, "public", "css"), { maxAge: "30d" }));
  app.use("/js", express.static(path.join(__dirname, "public", "js"), { maxAge: "30d" }));
  app.use("/fonts", express.static(path.join(__dirname, "public", "fonts"), { maxAge: "30d" }));

  const SqliteStore = SqliteStoreFactory(session);
  app.use(session({
    store: new SqliteStore({ client: db, expired: { clear: true, intervalMs: 15 * 60 * 1000 } }),
    secret,
    name: "session",
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true, sameSite: "lax", secure: env === "production",
      maxAge: 12 * 60 * 60 * 1000,
    },
  }));
  app.use(auth.loadUser(db));

  // ---- helpers shared by routes -----------------------------------------
  function plainSeo(title, desc, urlPath, noindex) {
    const s = D.getSettings(db);
    return core.buildSeo(s, { title: `${title} | ${s.site_name}`, description: desc, path: urlPath, noindex: !!noindex });
  }
  app.locals.plainSeo = plainSeo;

  function assetUrl(rel) {
    const p = path.join(__dirname, "public", rel);
    let v = 0;
    try { v = Math.floor(fs.statSync(p).mtimeMs / 1000); } catch (_) { /* missing is fine */ }
    return "/" + rel + "?v=" + v;
  }

  app.use((req, res, next) => {
    res.locals.site = D.getSettings(db);
    const rows = db.prepare("SELECT * FROM menu_items ORDER BY location, sort_order, id").all();
    const menus = {};
    for (const r of rows) (menus[r.location] = menus[r.location] || []).push(r);
    res.locals.menus = menus;
    res.locals.asset = assetUrl;
    res.locals.csrfToken = () => auth.csrfToken(req);
    res.locals.currentUser = () => auth.currentUser(req);
    res.locals.C = require("./src/lib/converter");
    res.locals.year = new Date().getUTCFullYear();
    res.locals.request = { path: req.path };
    next();
  });

  // date filters (used by EJS templates as helpers on res.locals)
  app.use((req, res, next) => {
    res.locals.datefmt = (s) => {
      const t = String(s || "").slice(0, 10);
      const d = new Date(t + "T00:00:00Z");
      if (isNaN(d)) return s || "";
      return d.toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric", timeZone: "UTC" });
    };
    res.locals.dtfmt = (s) => {
      const t = String(s || "").replace(" ", "T");
      const d = new Date(t.length <= 16 ? t + ":00Z" : t + "Z");
      if (isNaN(d)) return s || "";
      const date = d.toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric", timeZone: "UTC" });
      const time = d.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", hour12: false, timeZone: "UTC" });
      return `${date}, ${time}`;
    };
    res.locals.md = (t) => CT.renderMd(t || "").html;
    next();
  });

  app.use((req, res, next) => {
    res.set("X-Content-Type-Options", "nosniff");
    res.set("X-Frame-Options", "SAMEORIGIN");
    res.set("Referrer-Policy", "strict-origin-when-cross-origin");
    res.set("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
    if (req.path.startsWith("/admin")) {
      res.set("X-Robots-Tag", "noindex, nofollow");
      res.set("Cache-Control", "no-store");
    }
    next();
  });

  // canonical host redirect
  const canonicalHost = process.env.CANONICAL_HOST;
  app.use((req, res, next) => {
    const host = (req.headers.host || "").split(":")[0];
    if (canonicalHost && host !== canonicalHost && host !== "localhost" && host !== "127.0.0.1") {
      return res.redirect(301, `${req.protocol}://${canonicalHost}${req.originalUrl}`);
    }
    next();
  });

  db.__testHandle = true; // marker only

  const adminRouter = require("./src/routes/admin")(db);
  app.use("/admin", adminRouter);

  registerPublicRoutes(app, db);
  registerErrorHandlers(app, db);

  app.locals.db = db; // exposed for tests only
  app.locals.secretKeyForTest = secret; // exposed for tests only
  return app;
}

// --------------------------------------------------------------- rendering
function renderPage(req, res, db, urlPath) {
  const row = core.getPage(db, urlPath);
  if (!row) return notFound(req, res, db);
  const s = D.getSettings(db);
  const tpl = row.template;
  const conf = core.parseJson(row.converter_json, {});
  const faq = core.parseFaq(row.faq_json);
  const raw = row.content_md || "";
  const hasChart = raw.includes("[[chart]]");
  const [beforeMd, afterMd] = hasChart ? raw.split("[[chart]]") : [raw, ""];
  const before = CT.renderMd(beforeMd);
  const after = afterMd.trim() ? CT.renderMd(afterMd) : { html: "", toc: [] };
  const toc = before.toc.concat(after.toc);
  const faqHtml = faq.map((f) => ({ q: f.q, a: CT.renderMd(f.a).html }));
  const crumbs = core.breadcrumbs(db, urlPath, core.labelOf(row));
  const desc = row.meta_description || CT.firstParagraphText(raw, 155);

  const ctx = {
    page: row, htmlBefore: before.html, htmlAfter: after.html, toc, faq: faqHtml, crumbs,
    related: core.relatedPages(db, row.related), words: CT.wordCount(raw),
    form: {}, errors: [], sent: req.query.sent === "1",
  };

  const graph = [];
  if (urlPath === "/") graph.push(core.jsonldOrg(s), core.jsonldWebsite(s));
  if (tpl === "home" || tpl === "converter") {
    ctx.cv = core.converterState(conf);
    graph.push(core.jsonldWebapp(s, row.title, urlPath, desc));
  }
  if (tpl === "calculator") graph.push(core.jsonldWebapp(s, row.title, urlPath, desc));
  if (tpl === "chart_kj") { ctx.chart = core.chartRows(db, s, "kj", SEED_FALLBACK_KJ_CHART); ctx.chartKind = "kj"; }
  if (tpl === "chart_cal") { ctx.chart = core.chartRows(db, s, "cal", SEED_FALLBACK_CAL_CHART); ctx.chartKind = "cal"; }
  if (tpl === "hub_convert") {
    ctx.kjValues = core.enabledValues(db, "kj-to-cal").map((r) => ({ ...core.valueFacts(r), url: core.valuePath(r.direction, r.value) }));
    ctx.calValues = core.enabledValues(db, "cal-to-kj").map((r) => ({ ...core.valueFacts(r), url: core.valuePath(r.direction, r.value) }));
  }
  if (tpl === "hub_guides") ctx.items = core.visiblePages(db, "kind='guide'", [], "sort_order, title");
  if (tpl === "hub_tools") ctx.items = core.visiblePages(db, "kind='tool'", [], "sort_order, title");
  if (row.kind === "guide" || (tpl === "article" && row.category)) graph.push(core.jsonldArticle(s, row, urlPath, desc));
  if (urlPath !== "/") graph.push(core.jsonldBreadcrumbs(s, crumbs));
  if (faq.length) graph.push(core.jsonldFaq(faq));

  ctx.seo = core.buildSeo(s, {
    title: core.pageTitle(s, row), description: desc, path: urlPath, noindex: !!row.noindex,
    canonical: row.canonical, ogImage: row.og_image, ogType: row.kind === "guide" ? "article" : "website", graph,
  });
  res.render("page", ctx);
}

function renderValue(req, res, db, row) {
  const s = D.getSettings(db);
  const f = core.valueFacts(row);
  const { title: dTitle, desc: dDesc, h1 } = core.valueSeoDefaults(f);
  const urlPath = core.valuePath(row.direction, row.value);
  const n = f.nPlain;
  let faq;
  if (row.direction === "kj-to-cal") {
    faq = [
      [`How many calories is ${n} kJ?`, `${n} kJ is ${f.main} kcal (food calories). Divide ${n} by 4.184 to check.`],
      [`How many small calories (cal) is ${n} kJ?`, `${n} kJ is ${f.alt} cal, since 1 kcal is 1,000 cal.`],
      [`What percentage of a daily intake is ${n} kJ?`, `About ${f.pctAu}% of the 8,700 kJ reference day used in Australia and New Zealand, or about ${f.pctRefKcal}% of a 2,000 kcal reference day.`],
    ];
  } else {
    faq = [
      [`How many kJ is ${n} calories?`, `${n} calories (kcal) is ${f.main} kJ. Multiply ${n} by 4.184 to check.`],
      [`How many joules is ${n} kcal?`, `${n} kcal is ${f.joules} J, since 1 kcal is 4,184 J.`],
      [`What percentage of a daily intake is ${n} kcal?`, `About ${f.pctRefKcal}% of a 2,000 kcal reference day, or about ${f.pctAu}% of the 8,700 kJ reference day.`],
    ];
  }
  const faqHtml = faq.map(([q, a]) => ({ q, a: CT.renderMd(a).html }));
  const notesHtml = row.notes_md ? CT.renderMd(row.notes_md).html : "";
  const cv = core.converterState({
    from: f.frm, to: f.to, value: f.nPlain,
    presets: row.direction === "kj-to-cal" ? [100, 500, 1000, 2000, 8700] : [100, 250, 500, 2000, 2500],
  });
  const crumbs = [["Home", "/"], ["Popular conversions", "/convert/"], [h1, urlPath]];
  const title = row.seo_title || dTitle;
  const desc = row.meta_description || dDesc;
  const graph = [core.jsonldWebapp(s, h1, urlPath, desc), core.jsonldBreadcrumbs(s, crumbs), core.jsonldFaq(faq.map(([q, a]) => ({ q, a })))];
  const seo = core.buildSeo(s, { title, description: desc, path: urlPath, graph });
  const related = core.relatedPages(db, "/how-to-convert-kj-to-calories/\n/kj-to-calories-chart/\n/calories-to-kj-chart/\n/kj-vs-calories/");
  res.render("value", { row, f, h1, cv, notesHtml, faq: faqHtml, crumbs, nearby: core.neighbors(db, row), seo, related, updated: row.updated_at });
}

function notFound(req, res, db) {
  logNotFound(req, db);
  const suggestions = core.visiblePages(db, "path IN ('/','/calories-to-kj/','/kj-to-calories-chart/','/how-to-convert-kj-to-calories/','/convert/')")
    .map((r) => ({ url: r.path, label: core.labelOf(r) }));
  const s = D.getSettings(db);
  res.status(404).render("404", { seo: core.buildSeo(s, { title: `Page not found | ${s.site_name}`, description: "The page you were looking for could not be found.", path: req.path, noindex: true }), suggestions });
}

function logNotFound(req, db) {
  const p = req.path.slice(0, 250);
  if (p.startsWith("/img/") || p.startsWith("/css/") || p.startsWith("/js/") || p.startsWith("/fonts/") || p.includes("\0")) return;
  try {
    const cnt = db.prepare("SELECT COUNT(*) c FROM not_found").get().c;
    const ref = (req.headers.referer || "").slice(0, 250);
    const exists = db.prepare("SELECT 1 FROM not_found WHERE path=?").get(p);
    if (cnt < 5000 || exists) {
      db.prepare(`INSERT INTO not_found(path,hits,last_seen,referrer) VALUES(?,1,?,?)
        ON CONFLICT(path) DO UPDATE SET hits=hits+1, last_seen=excluded.last_seen,
        referrer=CASE WHEN excluded.referrer!='' THEN excluded.referrer ELSE referrer END`).run(p, D.now(), ref);
    }
  } catch (_) { /* never break a 404 because logging failed */ }
}

function checkRedirect(db, p) {
  const alts = new Set([p, p.replace(/\/$/, "") || "/", p.endsWith("/") ? p : p + "/"]);
  for (const a of alts) {
    const r = db.prepare("SELECT * FROM redirects WHERE from_path=? AND enabled=1").get(a);
    if (r) {
      db.prepare("UPDATE redirects SET hits=hits+1 WHERE id=?").run(r.id);
      return r;
    }
  }
  return null;
}

// -------------------------------------------------------------- contact
const EMAIL_RE = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;

function handleContact(req, res, db, row) {
  const ip = req.ip || "?";
  const form = { name: (req.body.name || "").trim(), email: (req.body.email || "").trim(), subject: (req.body.subject || "").trim(), message: (req.body.message || "").trim() };
  const errors = [];
  if (req.body.website) return res.redirect(303, row.path + "?sent=1"); // honeypot
  if (D.rateLimited(db, "contact:" + ip, 5, 3600)) errors.push("You have sent several messages recently. Please try again later.");
  if (!form.name || form.name.length > 100) errors.push("Enter your name (up to 100 characters).");
  if (!EMAIL_RE.test(form.email) || form.email.length > 200) errors.push("Enter a valid email address.");
  if (form.message.length < 10 || form.message.length > 5000) errors.push("Your message should be between 10 and 5,000 characters.");
  if (form.subject.length > 150) errors.push("Keep the subject under 150 characters.");
  if (errors.length) return renderContactError(req, res, db, row, form, errors);
  D.rateHit(db, "contact:" + ip);
  db.prepare("INSERT INTO messages(name,email,subject,body,created_at) VALUES(?,?,?,?,?)").run(form.name, form.email, form.subject, form.message, D.now());
  notifyEmail(db, form).catch(() => {});
  res.redirect(303, row.path + "?sent=1");
}

function renderContactError(req, res, db, row, form, errors) {
  const s = D.getSettings(db);
  const before = CT.renderMd(row.content_md);
  const crumbs = core.breadcrumbs(db, row.path, core.labelOf(row));
  const seo = core.buildSeo(s, { title: core.pageTitle(s, row), description: row.meta_description, path: row.path, noindex: true });
  res.status(422).render("page", {
    page: row, htmlBefore: before.html, htmlAfter: "", toc: [], faq: [], crumbs, related: [], words: 0, seo,
    form, errors, sent: false,
  });
}

async function notifyEmail(db, form) {
  const host = process.env.SMTP_HOST;
  const to = D.getSettings(db).smtp_notify_to || process.env.SMTP_TO;
  if (!host || !to) return;
  // Minimal, dependency-free SMTP notification is out of scope for this build;
  // messages are always stored in the admin panel regardless of email delivery.
}

// --------------------------------------------------------------- routes
function registerPublicRoutes(app, db) {
  app.get("/", (req, res) => renderPage(req, res, db, "/"));

  app.get("/convert/:slug/", (req, res) => {
    const parsed = core.parseValueSlug(req.params.slug.toLowerCase());
    if (!parsed) return fallbackOr404(req, res, db);
    const row = core.getValueRow(db, ...parsed);
    if (!row) return fallbackOr404(req, res, db);
    renderValue(req, res, db, row);
  });

  app.get("/convert/:slug", (req, res) => {
    const parsed = core.parseValueSlug(req.params.slug.toLowerCase());
    if (parsed && core.getValueRow(db, ...parsed)) return res.redirect(301, `/convert/${req.params.slug.toLowerCase()}/`);
    fallbackOr404(req, res, db);
  });

  app.get("/sitemap.xml", (req, res) => {
    const s = D.getSettings(db);
    const base = s.base_url.replace(/\/$/, "");
    const urls = [];
    for (const r of core.visiblePages(db, "in_sitemap=1 AND noindex=0", [], "path")) urls.push([base + r.path, (r.updated_at || "").slice(0, 10)]);
    for (const r of db.prepare("SELECT * FROM convert_values WHERE enabled=1").all()) urls.push([base + core.valuePath(r.direction, r.value), (r.updated_at || "").slice(0, 10)]);
    const esc = (x) => x.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
    const body = ['<?xml version="1.0" encoding="UTF-8"?>', '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'];
    for (const [u, lm] of urls) body.push(`<url><loc>${esc(u)}</loc>${lm ? `<lastmod>${lm}</lastmod>` : ""}</url>`);
    body.push("</urlset>");
    res.type("application/xml").send(body.join("\n"));
  });

  app.get("/robots.txt", (req, res) => {
    const s = D.getSettings(db);
    res.type("text/plain").send(s.robots_txt.replace("{base_url}", s.base_url.replace(/\/$/, "")) + "\n");
  });

  app.get("/favicon.ico", (req, res) => res.sendFile(path.join(__dirname, "public", "img", "favicon.ico")));

  if (storage.enabled()) {
    // Object storage mode: redirect to a public or short-lived signed URL. Nothing is read
    // from local disk, so this works even on hosts that wipe local files between deploys.
    app.get("/media/:filename", async (req, res) => {
      try {
        const url = await storage.mediaUrl(req.params.filename);
        res.redirect(302, url);
      } catch (e) {
        res.status(404).end();
      }
    });
  } else {
    app.use("/media", express.static(path.join(process.env.KJ_INSTANCE || path.join(__dirname, "instance"), "uploads"), { maxAge: "30d", dotfiles: "deny" }));
  }

  app.post("/contact/", auth.checkCsrf, (req, res) => {
    const row = core.getPage(db, "/contact/");
    if (!row || row.template !== "contact") return res.status(405).render("error", { code: 405, message: "That action is not allowed on this page.", seo: app.locals.plainSeo("Method not allowed", "", req.path, true) });
    handleContact(req, res, db, row);
  });

  app.get("*", (req, res) => {
    const p = req.path;
    if (p.startsWith("/admin")) return notFound(req, res, db);
    const r = checkRedirect(db, p);
    if (r) return res.redirect(r.code, r.to_url);
    const norm = CT.normalizePath(p);
    const row = core.getPage(db, norm);
    if (row) {
      if (p !== norm) {
        const qs = req.url.includes("?") ? "?" + req.url.split("?")[1] : "";
        return res.redirect(301, norm + qs);
      }
      return renderPage(req, res, db, norm);
    }
    notFound(req, res, db);
  });
}

function fallbackOr404(req, res, db) {
  const r = checkRedirect(db, req.path);
  if (r) return res.redirect(r.code, r.to_url);
  notFound(req, res, db);
}

// ----------------------------------------------------------- error handlers
function registerErrorHandlers(app, db) {
  app.use((req, res) => notFound(req, res, db)); // safety net
  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    if (res.headersSent) return next(err);
    console.error(err);
    if (err.type === "entity.too.large") {
      res.status(413);
      return res.render("error", { code: 413, message: "That upload is too large (6 MB maximum).", seo: app.locals.plainSeo("Upload too large", "", req.path, true) });
    }
    res.status(500);
    res.render("error", { code: 500, message: "Something went wrong on our side. Please try again shortly.", seo: app.locals.plainSeo("Server error", "", req.path, true) });
  });
}

function startServer() {
  return restoreFromObjectStorageIfNeeded()
    .catch((e) => console.error("Object storage restore failed (continuing with a fresh database):", e.message))
    .then(() => {
      const app = createApp();
      const rawPort = process.env.PORT;
      const host = process.env.HOST || "0.0.0.0";

      let server;
      if (rawPort && !isNaN(Number(rawPort))) {
        const p = Number(rawPort);
        server = process.env.HOST ? app.listen(p, process.env.HOST, () => console.log(`KJ to Cal listening on ${process.env.HOST}:${p}`)) : app.listen(p, () => console.log(`KJ to Cal listening on port ${p}`));
      } else if (rawPort) {
        server = app.listen(rawPort, () => console.log(`KJ to Cal listening on ${rawPort}`));
      } else {
        server = app.listen(3000, () => console.log(`KJ to Cal listening on port 3000`));
      }

      // On a graceful shutdown, take one last backup before exiting
      let shuttingDown = false;
      function shutdown() {
        if (shuttingDown) return;
        shuttingDown = true;
        if (!storage.enabled()) { server.close(() => process.exit(0)); return; }
        const db = app.locals.db;
        const timer = setTimeout(() => process.exit(0), 5000);
        storage.backupDatabase(db)
          .catch((e) => console.error("Final backup failed:", e.message))
          .then(() => { clearTimeout(timer); server.close(() => process.exit(0)); });
      }
      process.on("SIGTERM", shutdown);
      process.on("SIGINT", shutdown);
      return server;
    });
}

module.exports = { createApp, restoreFromObjectStorageIfNeeded, startServer };

if (require.main === module) {
  startServer();
}

