"use strict";
const { startServer } = require("./app.js");
startServer();
