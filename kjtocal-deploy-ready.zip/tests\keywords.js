"use strict";
/** Check that every mapped keyword appears (exact phrase) on its target page. Mirrors tests/keywords.py. */
const http = require("http");
const { URL } = require("url");
const path = require("path");

const BASE = process.env.BASE_URL || "http://localhost:5091";

function get(p) {
  return new Promise((resolve) => {
    const u = new URL(p, BASE);
    http.request(u, { method: "GET" }, (res) => {
      let data = "";
      res.on("data", (c) => (data += c));
      res.on("end", () => resolve(data));
    }).on("error", () => resolve("")).end();
  });
}

function visibleText(html) {
  html = html.replace(/<(script|style)[^>]*>[\s\S]*?<\/\1>/g, " ");
  const title = (/<title>([\s\S]*?)<\/title>/.exec(html) || [, ""])[1];
  const desc = (/<meta name="description" content="([^"]*)"/.exec(html) || [, ""])[1];
  const body = html.replace(/<[^>]+>/g, " ");
  const all = (title + " " + desc + " " + body)
    .replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'");
  return all.replace(/\s+/g, " ").toLowerCase();
}

async function main() {
  // keywords.tsv isn't JSON; parse the .tsv directly instead:
  const fs = require("fs");
  const tsv = fs.readFileSync(path.join(__dirname, "..", "src", "data", "keywords.tsv"), "utf8");
  const seed = require(path.join(__dirname, "..", "src", "data", "seed-content.json"));
  const typoSet = new Set(seed.typoKeywords);
  const kjValues = seed.kjValues;

  function mapKeyword(k) {
    if (typoSet.has(k)) return ["/", "ignore"];
    let m = /^(\d+) kj to/.exec(k);
    if (m && kjValues.includes(Number(m[1]))) return [`/convert/${m[1]}-kj-to-calories/`, "mapped"];
    if (k.includes("kj to cal") && k.startsWith("calorie converter")) return ["/", "mapped"];
    if (/^(cal|cals|calorie|calories)\b/.test(k) || /^convert (cal|calorie) to kj/.test(k)) return ["/calories-to-kj/", "mapped"];
    if (/\b(how to|how do i|how do you|formula|equation|calculate|conversion)\b/.test(k) && !k.includes("calculator") && !/^how many|^what is/.test(k)) {
      return ["/how-to-convert-kj-to-calories/", "mapped"];
    }
    if (/^(how many|what is)/.test(k) || k.includes("is how many") || ["kj in cal", "kj in calorie", "kj in calories"].includes(k)) {
      return ["/how-many-kj-in-a-calorie/", "mapped"];
    }
    return ["/", "mapped"];
  }

  const rows = [];
  for (const line of tsv.split("\n")) {
    const parts = line.split("\t");
    if (!parts[0] || !parts[0].trim()) continue;
    const kw = parts[0].trim().toLowerCase();
    const vol = parseInt(parts[3], 10) || 0;
    const [mappedPath, status] = mapKeyword(kw);
    rows.push({ keyword: kw, volume: vol, mappedPath, status });
  }
  const mapped = rows.filter((r) => r.status === "mapped").sort((a, b) => b.volume - a.volume);
  const ignored = rows.filter((r) => r.status === "ignore").map((r) => r.keyword);

  const cache = {};
  const missing = [];
  for (const r of mapped) {
    if (!(r.mappedPath in cache)) cache[r.mappedPath] = visibleText(await get(r.mappedPath));
    if (!cache[r.mappedPath].includes(r.keyword)) missing.push([r.volume, r.keyword, r.mappedPath]);
  }
  console.log(`mapped keywords: ${mapped.length}, covered: ${mapped.length - missing.length}, missing: ${missing.length}`);
  missing.forEach((m) => console.log("  MISSING", m));
  console.log("ignored (typos):", ignored);
  process.exit(missing.length ? 1 : 0);
}

main();
