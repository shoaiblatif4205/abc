const { createApp } = require("../app");
try {
  const app = createApp({ TESTING: true });
  process.send({ ok: true, secret: app.locals.secretKeyForTest || "" });
  process.exit(0);
} catch (e) {
  process.send({ ok: false, error: e.stack });
  process.exit(1);
}
