/* KJ to Cal — converter and calculator. Vanilla JS, no dependencies.
   Factors are exact: 1 cal = 4.184 J. formatValue() mirrors converter.fmt() in converter.py. */
(function () {
  'use strict';
  var J = { j: 1, kj: 1000, cal: 4.184, kcal: 4184 };
  var SYM = { j: 'J', kj: 'kJ', cal: 'cal', kcal: 'kcal' };
  var ORDER = ['kj', 'kcal', 'cal', 'j'];
  var FORMULAS = {
    'kj>kcal': 'kcal = kJ ÷ 4.184', 'kcal>kj': 'kJ = kcal × 4.184',
    'kj>cal': 'cal = kJ × 1000 ÷ 4.184  (≈ kJ × 239.006)', 'cal>kj': 'kJ = cal × 4.184 ÷ 1000  (= cal × 0.004184)',
    'kj>j': 'J = kJ × 1000', 'j>kj': 'kJ = J ÷ 1000', 'kcal>cal': 'cal = kcal × 1000', 'cal>kcal': 'kcal = cal ÷ 1000',
    'kcal>j': 'J = kcal × 4184', 'j>kcal': 'kcal = J ÷ 4184', 'cal>j': 'J = cal × 4.184', 'j>cal': 'cal = J ÷ 4.184'
  };
  var MAX = 1e12;

  function nf(dp) {
    return new Intl.NumberFormat('en-US', { minimumFractionDigits: 0, maximumFractionDigits: Math.min(dp, 20) });
  }
  /* Round half-up on the decimal value, ignoring binary floating-point noise (e.g. 0.21895 -> 0.2190). */
  function roundHalfUp(x, dp) {
    var s = Math.pow(10, dp), y = x * s;
    if (Math.abs(y) < 1e11) { return Math.round(Number(y.toPrecision(12))) / s; }
    return x;
  }
  function formatValue(x) {
    if (x === 0) return '0';
    var ax = Math.abs(x), dp;
    if (ax < 0.01) {
      var exp = parseInt(ax.toExponential().split('e')[1], 10); // decimal exponent of the leading digit
      dp = Math.max(0, 3 - exp);
    } else {
      dp = ax < 1 ? 4 : ax < 100 ? 3 : ax < 10000 ? 2 : 1;
    }
    return nf(dp).format(roundHalfUp(x, dp));
  }
  function fmtPct(p) {
    if (p < 0.1) return 'less than 0.1';
    var dp = p < 10 ? 1 : 0;
    return nf(dp).format(roundHalfUp(p, dp));
  }
  /* Accepts 1,234.5  1 234,5  1.234,5  1234  1,5 (decimal comma) */
  function parseNum(s) {
    s = String(s).trim().replace(/\s+/g, '');
    if (!s) return NaN;
    if (s.indexOf('.') > -1 && s.indexOf(',') > -1) {
      if (s.lastIndexOf(',') > s.lastIndexOf('.')) s = s.replace(/\./g, '').replace(',', '.');
      else s = s.replace(/,/g, '');
    } else if (s.indexOf(',') > -1) {
      if (/^\d{1,3}(,\d{3})+$/.test(s)) s = s.replace(/,/g, '');
      else s = s.replace(',', '.');
    }
    if (!/^\d*\.?\d+$|^\d+\.$/.test(s)) return NaN;
    return parseFloat(s);
  }

  function initConverter(root) {
    var input = root.querySelector('[data-in]');
    var fromSel = root.querySelector('[data-from-sel]');
    var toSel = root.querySelector('[data-to-sel]');
    var errEl = root.querySelector('[data-err]');
    var rVal = root.querySelector('[data-r-value]');
    var rUnit = root.querySelector('[data-r-unit]');
    var eq = root.querySelector('[data-eq]');
    var formula = root.querySelector('[data-formula]');
    var meter = root.querySelector('[data-meter]');
    var bar = root.querySelector('[data-bar]');
    var pctEl = root.querySelector('[data-pct]');
    var swap = root.querySelector('[data-swap]');
    var copyBtn = root.querySelector('[data-copy]');

    function setErr(msg) {
      input.setAttribute('aria-invalid', msg ? 'true' : 'false');
      errEl.hidden = !msg;
      errEl.textContent = msg || '';
    }
    function update() {
      var frm = fromSel.value, to = toSel.value;
      fromSel.className = 'u-' + frm; toSel.className = 'u-' + to;
      rUnit.className = 'cv-unit u-' + to; rUnit.textContent = SYM[to];
      formula.textContent = FORMULAS[frm + '>' + to] || '';
      var raw = input.value;
      var v = parseNum(raw);
      if (raw.trim() === '') { setErr(''); rVal.textContent = '–'; eq.textContent = 'Enter an amount to convert.'; return; }
      if (/^\s*-/.test(raw)) { setErr('Enter a positive number. Energy amounts cannot be negative here.'); rVal.textContent = '–'; return; }
      if (isNaN(v)) { setErr('Enter a number, for example 2000 or 1,250.5.'); rVal.textContent = '–'; return; }
      if (v < 0) { setErr('Enter a positive number. Energy amounts cannot be negative here.'); rVal.textContent = '–'; return; }
      if (v > MAX) { setErr('Enter a number up to 1,000,000,000,000.'); rVal.textContent = '–'; return; }
      setErr('');
      var joules = v * J[frm];
      ORDER.forEach(function (u) {
        var el = root.querySelector('[data-all="' + u + '"]');
        if (el) el.textContent = formatValue(joules / J[u]) + ' ' + SYM[u];
      });
      var res = formatValue(joules / J[to]);
      rVal.textContent = res;
      eq.textContent = formatValue(v) + ' ' + SYM[frm] + ' = ' + res + ' ' + SYM[to];
      if (meter) {
        var pct = (joules / 1000) / 8700 * 100;
        meter.hidden = pct < 0.1;
        bar.style.width = Math.min(pct, 100) + '%';
        pctEl.textContent = fmtPct(pct) + '%';
      }
    }
    input.addEventListener('input', update);
    fromSel.addEventListener('change', update);
    toSel.addEventListener('change', update);
    swap.addEventListener('click', function () {
      var a = fromSel.value; fromSel.value = toSel.value; toSel.value = a;
      swap.classList.toggle('spin'); update();
    });
    root.querySelectorAll('[data-preset]').forEach(function (b) {
      b.addEventListener('click', function () { input.value = b.getAttribute('data-preset'); update(); input.focus(); });
    });
    if (copyBtn) copyBtn.addEventListener('click', function () {
      var t = eq.textContent;
      var done = function () { var o = copyBtn.textContent; copyBtn.textContent = 'Copied'; setTimeout(function () { copyBtn.textContent = o; }, 1500); };
      if (navigator.clipboard && window.isSecureContext) { navigator.clipboard.writeText(t).then(done, done); }
      else { var ta = document.createElement('textarea'); ta.value = t; document.body.appendChild(ta); ta.select(); try { document.execCommand('copy'); } catch (e) {} document.body.removeChild(ta); done(); }
    });
    // optional URL prefill: ?v=2000&from=kj&to=kcal
    try {
      var p = new URLSearchParams(location.search);
      if (p.get('from') && J[p.get('from')]) fromSel.value = p.get('from');
      if (p.get('to') && J[p.get('to')]) toSel.value = p.get('to');
      if (p.get('v') && !isNaN(parseNum(p.get('v')))) input.value = p.get('v');
    } catch (e) {}
    update();
  }

  function initCalc(root) {
    var $ = function (s) { return root.querySelector(s); };
    var err = $('[data-err]');
    var unitsRadios = root.querySelectorAll('input[name=units]');
    var metricEls = root.querySelectorAll('[data-metric]');
    var impEls = root.querySelectorAll('[data-imperial]');
    function units() { return root.querySelector('input[name=units]:checked').value; }
    function sex() { return root.querySelector('input[name=sex]:checked').value; }
    function num(id) { return parseFloat($(id).value); }
    function setErr(m) { err.hidden = !m; err.textContent = m || ''; }
    var dirtyImp = false; // true once the user edits the imperial fields
    ['#c-ft', '#c-in', '#c-lb'].forEach(function (id) { $(id).addEventListener('input', function () { dirtyImp = true; }); });
    function calc() {
      var age = num('#c-age'), h, w;
      if (units() === 'metric' || !dirtyImp) { h = num('#c-h'); w = num('#c-w'); }
      else { h = (num('#c-ft') * 12 + num('#c-in')) * 2.54; w = num('#c-lb') * 0.45359237; }
      var act = parseFloat($('#c-act').value);
      var bad = null;
      if (!(age >= 18 && age <= 100)) bad = 'Enter an age between 18 and 100. This estimate is for adults.';
      else if (!(h >= 120 && h <= 230)) bad = 'Enter a height between 120 and 230 cm (about 3 ft 11 in to 7 ft 7 in).';
      else if (!(w >= 30 && w <= 300)) bad = 'Enter a weight between 30 and 300 kg (about 66 to 660 lb).';
      if (bad) { setErr(bad); ['bmr-kj', 'bmr-kcal', 'tdee-kj', 'tdee-kcal'].forEach(function (k) { $('[data-' + k + ']').textContent = '–'; }); return; }
      setErr('');
      var bmr = 10 * w + 6.25 * h - 5 * age + (sex() === 'male' ? 5 : -161);
      var tdee = bmr * act;
      $('[data-bmr-kj]').textContent = nf(0).format(bmr * 4.184);
      $('[data-bmr-kcal]').textContent = nf(0).format(bmr) + ' kcal';
      $('[data-tdee-kj]').textContent = nf(0).format(tdee * 4.184);
      $('[data-tdee-kcal]').textContent = nf(0).format(tdee) + ' kcal';
    }
    unitsRadios.forEach(function (r) {
      r.addEventListener('change', function () {
        var imp = units() === 'imperial';
        if (imp) {
          var cm = num('#c-h'), kg = num('#c-w');
          if (cm > 0) { var inches = cm / 2.54; $('#c-ft').value = Math.floor(inches / 12); $('#c-in').value = (inches % 12).toFixed(1); }
          if (kg > 0) $('#c-lb').value = (kg / 0.45359237).toFixed(1);
          dirtyImp = false;
        } else if (dirtyImp) {
          var tot = num('#c-ft') * 12 + num('#c-in'), lb = num('#c-lb');
          if (tot > 0) $('#c-h').value = (tot * 2.54).toFixed(1);
          if (lb > 0) $('#c-w').value = (lb * 0.45359237).toFixed(1);
          dirtyImp = false;
        }
        metricEls.forEach(function (e) { e.hidden = imp; });
        impEls.forEach(function (e) { e.hidden = !imp; });
        calc();
      });
    });
    root.addEventListener('input', calc);
    root.addEventListener('change', calc);
    calc();
  }

  window.KJ = { formatValue: formatValue, parseNum: parseNum, fmtPct: fmtPct, J: J };
  document.querySelectorAll('[data-cv]').forEach(initConverter);
  document.querySelectorAll('[data-calc]').forEach(initCalc);
})();
