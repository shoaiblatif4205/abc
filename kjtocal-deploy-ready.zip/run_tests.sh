#!/usr/bin/env bash
# Runs every automated check. Requires npm install to have been run.
set -e
cd "$(dirname "$0")"
echo "== 1/3 Public site crawl (status, H1, meta, canonical, JSON-LD, links, sitemap)"
echo "   (requires the app to be running: KJ_ENV=development BASE_URL set)"
node tests/crawl.js
echo "== 2/3 Keyword coverage"
node tests/keywords.js
echo "== 3/3 Concurrent first boot (multi-process safety)"
node tests/concurrent_boot.js
echo "ALL TEST SUITES PASSED"
