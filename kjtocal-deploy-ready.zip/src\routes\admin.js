"use strict";
/** Admin panel / CMS router. Mirrors admin.py. */
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const express = require("express");
const multer = require("multer");
const sharp = require("sharp");

const D = require("../lib/db");
const CT = require("../lib/content");
const core = require("../lib/core");
const auth = require("../lib/auth");
const ui = require("../lib/adminUi");
const C = require("../lib/converter");
const storage = require("../lib/storage");

const STATUSES = [["published", "Published"], ["draft", "Draft"], ["scheduled", "Scheduled"]];
const EMAIL_RE = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
const MENU_LOCATIONS = [
  ["header", "Header navigation"], ["footer_converters", "Footer: Converters"], ["footer_learn", "Footer: Learn"],
  ["footer_reference", "Footer: Reference"], ["footer_company", "Footer: Company"],
];
const ALLOWED_IMG = { png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", webp: "image/webp", gif: "image/gif" };
const seedData = require("../data/seed-content.json");
const KJ_CHART_FALLBACK = seedData.kjChart.map(([t, v]) => [t, v.map(Number)]);
const CAL_CHART_FALLBACK = seedData.calChart.map(([t, v]) => [t, v.map(Number)]);

module.exports = function (db) {
  const router = express.Router();
  const uploadDir = path.join(process.env.KJ_INSTANCE || path.join(__dirname, "..", "..", "instance"), "uploads");
  fs.mkdirSync(uploadDir, { recursive: true });
  const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 6 * 1024 * 1024, files: 20 } });

  const STAFF = auth.loginRequired();
  const ADMIN = auth.loginRequired("admin");

  // ---------------------------------------------------------------- helpers
  function flashOk(req, msg) { (req.session.flash = req.session.flash || []).push(["ok", msg]); }
  function flashErr(req, msg) { (req.session.flash = req.session.flash || []).push(["bad", msg]); }

  function render(req, res, view, locals) {
    const flashes = req.session.flash || [];
    req.session.flash = [];
    const me = auth.currentUser(req);
    const unread = me ? db.prepare("SELECT COUNT(*) c FROM messages WHERE is_read=0 AND is_spam=0").get().c : 0;
    res.render("admin/" + view, Object.assign({
      flashes, me, unread, ui, csrfToken: () => auth.csrfToken(req), STATUSES,
      TEMPLATES: core.TEMPLATES, KINDS: core.KINDS, req,
    }, locals));
  }

  function paginate(sqlBase, args, per, page) {
    per = per || 50;
    page = Math.max(1, page || 1);
    const total = db.prepare(`SELECT COUNT(*) c FROM (${sqlBase})`).get(...args).c;
    const rows = db.prepare(`${sqlBase} LIMIT ? OFFSET ?`).all(...args, per, (page - 1) * per);
    const pages = Math.max(1, Math.ceil(total / per));
    return [rows, { page, pages, total }];
  }

  function sameOriginNext(n) {
    return n && n.startsWith("/admin") && !n.startsWith("//") ? n : "/admin/";
  }

  function intOr(v, dflt, lo, hi) {
    lo = lo === undefined ? 0 : lo; hi = hi === undefined ? 100000 : hi;
    const n = parseInt(v, 10);
    if (Number.isNaN(n)) return dflt;
    return Math.min(hi, Math.max(lo, n));
  }

  // CSRF for every POST in this router, except multipart routes (handled explicitly after multer parses them).
  const MULTIPART_ROUTES = new Set(["/media/upload", "/keywords"]);
  router.use((req, res, next) => {
    if (req.method === "POST" && !MULTIPART_ROUTES.has(req.path)) return auth.checkCsrf(req, res, next);
    next();
  });

  // ------------------------------------------------------------------ auth
  router.get("/login", (req, res) => {
    if (auth.currentUser(req)) return res.redirect("/admin/");
    render(req, res, "login", {});
  });

  router.post("/login", (req, res) => {
    const ip = req.ip || "?";
    const uname = (req.body.username || "").trim();
    if (D.rateLimited(db, "login:" + ip, 8, 900)) {
      flashErr(req, "Too many failed sign-in attempts. Wait 15 minutes and try again.");
      res.status(429);
      return render(req, res, "login", {});
    }
    const u = db.prepare("SELECT * FROM users WHERE username=?").get(uname);
    if (u && auth.verifyPw(u.password_hash, req.body.password || "")) {
      req.session.regenerate((err) => {
        req.session.uid = u.id;
        auth.csrfToken(req);
        db.prepare("UPDATE users SET last_login=? WHERE id=?").run(D.now(), u.id);
        D.logActivity(db, u, "login");
        res.redirect(sameOriginNext(req.query.next));
      });
      return;
    }
    D.rateHit(db, "login:" + ip);
    flashErr(req, "Incorrect username or password.");
    res.status(401);
    render(req, res, "login", {});
  });

  router.post("/logout", (req, res) => {
    req.session.destroy(() => res.redirect("/admin/login"));
  });

  // ------------------------------------------------------------- dashboard
  router.get("/", STAFF, (req, res) => {
    const counts = {
      published: db.prepare("SELECT COUNT(*) c FROM pages WHERE status='published'").get().c,
      drafts: db.prepare("SELECT COUNT(*) c FROM pages WHERE status!='published'").get().c,
      value_pages: db.prepare("SELECT COUNT(*) c FROM convert_values WHERE enabled=1").get().c,
      media: db.prepare("SELECT COUNT(*) c FROM media").get().c,
      keywords: db.prepare("SELECT COUNT(*) c FROM keywords WHERE status='mapped'").get().c,
      notfound: db.prepare("SELECT COUNT(*) c FROM not_found").get().c,
    };
    const issues = [];
    for (const p of db.prepare("SELECT * FROM pages WHERE status='published' ORDER BY path").all()) {
      const bad = core.analysePage(p).filter(([lvl]) => lvl === "bad" || lvl === "warn");
      if (bad.length) issues.push([p, bad]);
    }
    const recent = db.prepare("SELECT * FROM pages ORDER BY updated_at DESC LIMIT 6").all();
    const activity = db.prepare("SELECT * FROM activity ORDER BY id DESC LIMIT 8").all();
    const top404 = db.prepare("SELECT * FROM not_found ORDER BY hits DESC LIMIT 5").all();
    const msgs = db.prepare("SELECT * FROM messages WHERE is_spam=0 ORDER BY id DESC LIMIT 4").all();
    render(req, res, "dashboard", { counts, issues: issues.slice(0, 6), issueTotal: issues.length, recent, activity, top404, msgs });
  });

  // ----------------------------------------------------------------- pages
  router.get("/pages", STAFF, (req, res) => {
    const s = (req.query.s || "").trim();
    const status = req.query.status || "";
    const kind = req.query.kind || "";
    const where = ["1=1"];
    const args = [];
    if (s) { where.push("(title LIKE ? OR path LIKE ? OR focus_keyword LIKE ?)"); args.push(`%${s}%`, `%${s}%`, `%${s}%`); }
    if (status) { where.push("status=?"); args.push(status); }
    if (kind) { where.push("kind=?"); args.push(kind); }
    const [rows, pg] = paginate(`SELECT * FROM pages WHERE ${where.join(" AND ")} ORDER BY path`, args, 100, intOr(req.query.page, 1, 1, 99999));
    render(req, res, "pages", { rows, pg, s, status, kind });
  });

  router.post("/pages/bulk", STAFF, (req, res) => {
    const ids = [].concat(req.body.ids || []).map((i) => parseInt(i, 10)).filter((i) => !Number.isNaN(i));
    const action = req.body.action;
    if (!ids.length) { flashErr(req, "Select at least one page."); return res.redirect("/admin/pages"); }
    const u = auth.currentUser(req);
    const ph = ids.map(() => "?").join(",");
    if (action === "published") {
      db.prepare(`UPDATE pages SET status='published', updated_at=? WHERE id IN (${ph})`).run(D.now(), ...ids);
      D.logActivity(db, u, "bulk-status", `published: ${ids.length} pages`);
      flashOk(req, `${ids.length} page(s) published.`);
    } else if (action === "draft") {
      db.prepare(`UPDATE pages SET status='draft', updated_at=? WHERE id IN (${ph}) AND path!='/'`).run(D.now(), ...ids);
      D.logActivity(db, u, "bulk-status", `draft: ${ids.length} pages`);
      flashOk(req, "Selected pages set to draft. The home page always stays published.");
    } else if (action === "delete") {
      if (u.role !== "admin") return res.status(403).end();
      const n = db.prepare(`SELECT COUNT(*) c FROM pages WHERE id IN (${ph}) AND path!='/'`).get(...ids).c;
      db.prepare(`DELETE FROM pages WHERE id IN (${ph}) AND path!='/'`).run(...ids);
      D.logActivity(db, u, "bulk-delete", `${n} pages`);
      flashOk(req, `Deleted ${n} page(s). The home page cannot be deleted.`);
    }
    res.redirect("/admin/pages");
  });

  function parseFaqBody(body) {
    const qs = [].concat(body.faq_q || []);
    const as_ = [].concat(body.faq_a || []);
    const out = [];
    for (let i = 0; i < qs.length; i++) {
      const q = (qs[i] || "").trim(), a = (as_[i] || "").trim();
      if (q && a) out.push({ q, a });
    }
    return out;
  }

  function blankPage() {
    return { id: 0, path: "/", kind: "page", template: "article", title: "", nav_label: "", seo_title: "",
      meta_description: "", canonical: "", noindex: 0, focus_keyword: "", secondary_keywords: "", og_image: "",
      intro: "", content_md: "", faq_json: "[]", converter_json: "{}", related: "", category: "",
      status: "draft", publish_at: "", in_sitemap: 1, sort_order: 100, author: "", created_at: "", updated_at: "" };
  }

  router.get("/pages/new", STAFF, (req, res) => showPageEditor(req, res, 0));
  router.get("/pages/:id(\\d+)/edit", STAFF, (req, res) => showPageEditor(req, res, parseInt(req.params.id, 10)));

  function showPageEditor(req, res, pid) {
    const row = pid ? db.prepare("SELECT * FROM pages WHERE id=?").get(pid) : null;
    if (pid && !row) return res.status(404).end();
    const page = row || blankPage();
    const conv = core.parseJson(page.converter_json, {});
    const faq = core.parseFaq(page.faq_json);
    const checks = pid ? core.analysePage(page) : [];
    const revs = pid ? db.prepare(
      "SELECT r.*, u.username FROM revisions r LEFT JOIN users u ON u.id=r.user_id WHERE page_id=? ORDER BY r.id DESC LIMIT 15"
    ).all(pid) : [];
    render(req, res, "page_edit", { page, faq, conv, isnew: !pid, checks, revs, words: CT.wordCount(page.content_md) });
  }

  router.post("/pages/new", STAFF, (req, res) => savePage(req, res, 0));
  router.post("/pages/:id(\\d+)/edit", STAFF, (req, res) => savePage(req, res, parseInt(req.params.id, 10)));

  function savePage(req, res, pid) {
    const row = pid ? db.prepare("SELECT * FROM pages WHERE id=?").get(pid) : null;
    if (pid && !row) return res.status(404).end();
    const page = row || blankPage();
    const f = req.body;
    const errors = [];
    const title = (f.title || "").trim();
    let urlPath = (f.path || "").trim() ? CT.normalizePath(f.path) : "";
    if (row && row.path === "/") urlPath = "/";
    if (!title) errors.push("Title is required.");
    if (!urlPath || !CT.validPath(urlPath)) errors.push("URL path may only contain lowercase letters, numbers and hyphens, e.g. /guides/my-page/.");
    else if (urlPath.startsWith("/admin/") || urlPath.startsWith("/static/") || urlPath.startsWith("/media/")) errors.push("That URL path is reserved.");
    else if (urlPath.startsWith("/convert/") && urlPath !== "/convert/") errors.push("Paths under /convert/ are managed in Value pages.");
    else {
      const dup = db.prepare("SELECT id FROM pages WHERE path=? AND id!=?").get(urlPath, pid);
      if (dup) errors.push("Another page already uses that URL path.");
    }
    let status = f.status || "draft";
    if (!STATUSES.some(([v]) => v === status)) status = "draft";
    let publishAt = "";
    if (status === "scheduled") {
      const m = /^(\d{4}-\d{2}-\d{2})T(\d{2}:\d{2})$/.exec(f.publish_at || "");
      if (!m) errors.push("Choose a valid publish date and time (UTC) for scheduled pages.");
      else publishAt = `${m[1]} ${m[2]}:00`;
    }
    let template = f.template || "article";
    if (!core.TEMPLATES.some(([v]) => v === template)) template = "article";
    let kind = f.kind || "page";
    if (!core.KINDS.some(([v]) => v === kind)) kind = "page";
    const conv = { from: f.conv_from || "kj", to: f.conv_to || "kcal" };
    if (!C.UNITS[conv.from] || !C.UNITS[conv.to]) errors.push("Choose valid converter units.");
    try { conv.value = core.normValue(f.conv_value || "1"); } catch (e) { errors.push("Converter default value must be a positive number (max 2 decimals)."); conv.value = "1"; }
    const pres = [];
    for (const tok of (f.conv_presets || "").trim().split(/[,\s]+/)) {
      if (!tok) continue;
      try {
        const pv = core.normValue(tok);
        pres.push(pv.includes(".") ? parseFloat(pv) : parseInt(pv, 10));
      } catch (e) { errors.push(`Preset "${tok}" is not a valid number.`); }
    }
    conv.presets = pres.slice(0, 8);
    const related = (f.related || "").split("\n").filter((l) => l.trim()).map((l) => CT.normalizePath(l)).join("\n");
    if ((f.meta_description || "").length > 320) errors.push("Meta description is far too long (320 characters max).");
    const canon = (f.canonical || "").trim();
    if (canon && !/^https?:\/\//.test(canon)) errors.push("Canonical URL must start with http:// or https://");
    const faq = parseFaqBody(f);
    const updated = Object.assign({}, page, {
      path: urlPath || page.path, kind, template, title, nav_label: (f.nav_label || "").trim(),
      seo_title: (f.seo_title || "").trim(), meta_description: (f.meta_description || "").trim(), canonical: canon,
      noindex: f.noindex ? 1 : 0, focus_keyword: (f.focus_keyword || "").trim(), secondary_keywords: (f.secondary_keywords || "").trim(),
      og_image: (f.og_image || "").trim(), intro: (f.intro || "").trim(), content_md: (f.content_md || "").replace(/\r\n/g, "\n"),
      faq_json: JSON.stringify(faq), converter_json: JSON.stringify(conv), related, category: (f.category || "").trim(),
      status, publish_at: publishAt, in_sitemap: f.in_sitemap ? 1 : 0, sort_order: intOr(f.sort_order, 100),
      author: (f.author || "").trim(),
    });
    if (errors.length) {
      errors.forEach((e) => flashErr(req, e));
      res.status(422);
      return render(req, res, "page_edit", { page: updated, faq, conv, isnew: !pid, checks: [], revs: [], words: CT.wordCount(updated.content_md) });
    }
    const u = auth.currentUser(req);
    const ts = D.now();
    const cols = ["path", "kind", "template", "title", "nav_label", "seo_title", "meta_description", "canonical", "noindex", "focus_keyword",
      "secondary_keywords", "og_image", "intro", "content_md", "faq_json", "converter_json", "related", "category", "status",
      "publish_at", "in_sitemap", "sort_order", "author"];
    if (pid) {
      db.prepare(`INSERT INTO revisions(page_id,title,intro,content_md,faq_json,seo_title,meta_description,note,user_id,created_at)
        VALUES(?,?,?,?,?,?,?,?,?,?)`).run(pid, row.title, row.intro, row.content_md, row.faq_json, row.seo_title, row.meta_description,
        (f.rev_note || "").trim().slice(0, 200), u.id, ts);
      db.prepare("DELETE FROM revisions WHERE page_id=? AND id NOT IN (SELECT id FROM revisions WHERE page_id=? ORDER BY id DESC LIMIT 40)").run(pid, pid);
      db.prepare(`UPDATE pages SET ${cols.map((c) => c + "=?").join(",")}, updated_at=? WHERE id=?`).run(...cols.map((c) => updated[c]), ts, pid);
      if (row.path !== urlPath && urlPath) {
        db.prepare("INSERT OR IGNORE INTO redirects(from_path,to_url,code,created_at) VALUES(?,?,301,?)").run(row.path, urlPath, ts);
        flashOk(req, `Saved. A 301 redirect from ${row.path} to ${urlPath} was added automatically.`);
      } else {
        flashOk(req, "Page saved.");
      }
      D.logActivity(db, u, "page-update", `${urlPath} (${status})`);
    } else {
      const info = db.prepare(`INSERT INTO pages(${cols.join(",")},created_at,updated_at) VALUES(${cols.map(() => "?").join(",")},?,?)`)
        .run(...cols.map((c) => updated[c]), ts, ts);
      pid = info.lastInsertRowid;
      flashOk(req, "Page created.");
      D.logActivity(db, u, "page-create", urlPath);
    }
    res.redirect(`/admin/pages/${pid}/edit`);
  }

  router.post("/pages/:id(\\d+)/delete", ADMIN, (req, res) => {
    const pid = parseInt(req.params.id, 10);
    const row = db.prepare("SELECT * FROM pages WHERE id=?").get(pid);
    if (!row) return res.status(404).end();
    if (row.path === "/") { flashErr(req, "The home page cannot be deleted."); return res.redirect(`/admin/pages/${pid}/edit`); }
    db.prepare("DELETE FROM pages WHERE id=?").run(pid);
    D.logActivity(db, auth.currentUser(req), "page-delete", row.path);
    flashOk(req, `Deleted ${row.path}. Consider adding a redirect for it.`);
    res.redirect("/admin/pages");
  });

  router.post("/pages/:id(\\d+)/duplicate", STAFF, (req, res) => {
    const pid = parseInt(req.params.id, 10);
    const row = db.prepare("SELECT * FROM pages WHERE id=?").get(pid);
    if (!row) return res.status(404).end();
    const base = row.path.replace(/\/$/, "") + "-copy";
    let p = base + "/", n = 2;
    while (db.prepare("SELECT 1 FROM pages WHERE path=?").get(p)) { p = `${base}-${n}/`; n++; }
    const ts = D.now();
    const info = db.prepare(`INSERT INTO pages(path,kind,template,title,nav_label,seo_title,meta_description,noindex,focus_keyword,secondary_keywords,
      intro,content_md,faq_json,converter_json,related,category,status,in_sitemap,sort_order,author,created_at,updated_at)
      SELECT ?,kind,template,title||' (copy)',nav_label,seo_title,meta_description,noindex,focus_keyword,secondary_keywords,
      intro,content_md,faq_json,converter_json,related,category,'draft',in_sitemap,sort_order,author,?,? FROM pages WHERE id=?`)
      .run(p, ts, ts, pid);
    D.logActivity(db, auth.currentUser(req), "page-duplicate", p);
    flashOk(req, "Duplicated as a draft. Change the URL path and title before publishing.");
    res.redirect(`/admin/pages/${info.lastInsertRowid}/edit`);
  });

  router.post("/pages/:id(\\d+)/revisions/:rid(\\d+)/restore", STAFF, (req, res) => {
    const pid = parseInt(req.params.id, 10), rid = parseInt(req.params.rid, 10);
    const r = db.prepare("SELECT * FROM revisions WHERE id=? AND page_id=?").get(rid, pid);
    if (!r) return res.status(404).end();
    const cur = db.prepare("SELECT * FROM pages WHERE id=?").get(pid);
    if (!cur) return res.status(404).end();
    const u = auth.currentUser(req);
    db.prepare(`INSERT INTO revisions(page_id,title,intro,content_md,faq_json,seo_title,meta_description,note,user_id,created_at)
      VALUES(?,?,?,?,?,?,?,?,?,?)`).run(pid, cur.title, cur.intro, cur.content_md, cur.faq_json, cur.seo_title, cur.meta_description, "Before restore", u.id, D.now());
    db.prepare("UPDATE pages SET title=?,intro=?,content_md=?,faq_json=?,seo_title=?,meta_description=?,updated_at=? WHERE id=?")
      .run(r.title, r.intro, r.content_md, r.faq_json, r.seo_title, r.meta_description, D.now(), pid);
    D.logActivity(db, u, "revision-restore", cur.path);
    flashOk(req, "Revision restored. The version you replaced was saved as a new revision.");
    res.redirect(`/admin/pages/${pid}/edit`);
  });

  router.post("/api/preview", STAFF, (req, res) => {
    const md = String((req.body && req.body.md) || "");
    const { html } = CT.renderMd(md.slice(0, 200000));
    res.json({ html });
  });

  // ------------------------------------------------------------ value pages
  router.get("/values", STAFF, (req, res) => {
    const d = req.query.d || "";
    const rows = d ? db.prepare("SELECT * FROM convert_values WHERE direction=?").all(d) : db.prepare("SELECT * FROM convert_values").all();
    rows.sort((a, b) => (a.direction === b.direction ? new C.Decimal(a.value).cmp(new C.Decimal(b.value)) : a.direction.localeCompare(b.direction)));
    const items = rows.map((r) => ({ r, f: core.valueFacts(r), path: core.valuePath(r.direction, r.value) }));
    render(req, res, "values", { items, d });
  });

  router.get("/values/new", STAFF, (req, res) => showValueEditor(req, res, 0));
  router.get("/values/:id(\\d+)/edit", STAFF, (req, res) => showValueEditor(req, res, parseInt(req.params.id, 10)));

  function showValueEditor(req, res, vid) {
    const row = vid ? db.prepare("SELECT * FROM convert_values WHERE id=?").get(vid) : null;
    if (vid && !row) return res.status(404).end();
    const v = row || { id: 0, direction: req.query.d || "kj-to-cal", value: "", notes_md: "", seo_title: "", meta_description: "", enabled: 1 };
    let preview = null;
    if (row) {
      const { title: dTitle, desc: dDesc, h1 } = core.valueSeoDefaults(core.valueFacts(row));
      preview = { title: dTitle, desc: dDesc, h1, path: core.valuePath(row.direction, row.value) };
    }
    render(req, res, "value_edit", { v, preview });
  }

  router.post("/values/new", STAFF, (req, res) => saveValue(req, res, 0));
  router.post("/values/:id(\\d+)/edit", STAFF, (req, res) => saveValue(req, res, parseInt(req.params.id, 10)));

  function saveValue(req, res, vid) {
    const row = vid ? db.prepare("SELECT * FROM convert_values WHERE id=?").get(vid) : null;
    if (vid && !row) return res.status(404).end();
    const v = row || { id: 0, direction: "kj-to-cal", value: "", notes_md: "", seo_title: "", meta_description: "", enabled: 1 };
    const f = req.body;
    const direction = f.direction || "kj-to-cal";
    const errors = [];
    if (direction !== "kj-to-cal" && direction !== "cal-to-kj") errors.push("Choose a direction.");
    let val = f.value || "";
    try { val = core.normValue(f.value || ""); } catch (e) { errors.push("Enter a positive number with at most 2 decimals (maximum 1,000,000,000)."); }
    if (!errors.length && db.prepare("SELECT id FROM convert_values WHERE direction=? AND value=? AND id!=?").get(direction, val, vid)) {
      errors.push("That value already exists for this direction.");
    }
    if ((f.meta_description || "").length > 320) errors.push("Meta description is too long.");
    const updated = Object.assign({}, v, { direction, value: val, notes_md: f.notes_md || "", seo_title: (f.seo_title || "").trim(),
      meta_description: (f.meta_description || "").trim(), enabled: f.enabled ? 1 : 0 });
    if (errors.length) {
      errors.forEach((e) => flashErr(req, e));
      res.status(422);
      return render(req, res, "value_edit", { v: updated, preview: null });
    }
    const ts = D.now();
    if (vid) {
      db.prepare("UPDATE convert_values SET direction=?,value=?,notes_md=?,seo_title=?,meta_description=?,enabled=?,updated_at=? WHERE id=?")
        .run(direction, val, updated.notes_md, updated.seo_title, updated.meta_description, updated.enabled, ts, vid);
      if (row.direction !== direction || row.value !== val) {
        db.prepare("INSERT OR IGNORE INTO redirects(from_path,to_url,code,created_at) VALUES(?,?,301,?)")
          .run(core.valuePath(row.direction, row.value), core.valuePath(direction, val), ts);
      }
    } else {
      const info = db.prepare("INSERT INTO convert_values(direction,value,notes_md,seo_title,meta_description,enabled,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)")
        .run(direction, val, updated.notes_md, updated.seo_title, updated.meta_description, updated.enabled, ts, ts);
      vid = info.lastInsertRowid;
    }
    D.logActivity(db, auth.currentUser(req), "value-save", core.valuePath(direction, val));
    flashOk(req, "Value page saved.");
    res.redirect(`/admin/values/${vid}/edit`);
  }

  router.post("/values/:id(\\d+)/delete", STAFF, (req, res) => {
    const vid = parseInt(req.params.id, 10);
    const r = db.prepare("SELECT * FROM convert_values WHERE id=?").get(vid);
    if (!r) return res.status(404).end();
    db.prepare("DELETE FROM convert_values WHERE id=?").run(vid);
    D.logActivity(db, auth.currentUser(req), "value-delete", core.valuePath(r.direction, r.value));
    flashOk(req, "Value page deleted.");
    res.redirect("/admin/values");
  });

  router.post("/values/generate", STAFF, (req, res) => {
    const direction = req.body.direction || "kj-to-cal";
    if (direction !== "kj-to-cal" && direction !== "cal-to-kj") return res.status(400).end();
    let added = 0, skipped = 0;
    const bad = [];
    for (const tok of (req.body.values || "").trim().split(/[,\s;]+/)) {
      if (!tok) continue;
      let val;
      try { val = core.normValue(tok); } catch (e) { bad.push(tok); continue; }
      if (db.prepare("SELECT 1 FROM convert_values WHERE direction=? AND value=?").get(direction, val)) { skipped++; continue; }
      db.prepare("INSERT INTO convert_values(direction,value,enabled,created_at,updated_at) VALUES(?,?,1,?,?)").run(direction, val, D.now(), D.now());
      added++;
    }
    D.logActivity(db, auth.currentUser(req), "values-generate", `${added} added`);
    flashOk(req, `Added ${added} value page(s); ${skipped} already existed.` + (bad.length ? ` Ignored invalid: ${bad.join(", ")}.` : ""));
    res.redirect(`/admin/values?d=${encodeURIComponent(direction)}`);
  });

  router.post("/values/:id(\\d+)/toggle", STAFF, (req, res) => {
    db.prepare("UPDATE convert_values SET enabled=1-enabled, updated_at=? WHERE id=?").run(D.now(), parseInt(req.params.id, 10));
    res.redirect(req.headers.referer || "/admin/values");
  });

  // ----------------------------------------------------------------- media
  router.get("/media", STAFF, (req, res) => {
    const [rows, pg] = paginate("SELECT * FROM media ORDER BY id DESC", [], 48, intOr(req.query.page, 1, 1, 99999));
    render(req, res, "media", { rows, pg });
  });

  router.get("/media/json", STAFF, (req, res) => {
    const rows = db.prepare("SELECT * FROM media ORDER BY id DESC LIMIT 200").all();
    res.json(rows.map((r) => ({ url: "/media/" + r.filename, alt: r.alt, name: r.original_name })));
  });

  router.post("/media/upload", STAFF, upload.array("files", 20), auth.checkCsrf, async (req, res) => {
    const files = req.files || [];
    if (!files.length) { flashErr(req, "Choose at least one image."); return res.redirect("/admin/media"); }
    let saved = 0;
    for (const f of files) {
      const extFromName = (f.originalname.includes(".") ? f.originalname.split(".").pop() : "").toLowerCase();
      if (!ALLOWED_IMG[extFromName]) { flashErr(req, `${f.originalname}: only PNG, JPG, WebP and GIF images are allowed.`); continue; }
      let meta;
      try {
        meta = await sharp(f.buffer, { animated: extFromName === "gif" }).metadata();
        if (!["png", "jpeg", "webp", "gif"].includes(meta.format)) throw new Error("format");
      } catch (e) {
        flashErr(req, `${f.originalname}: not a valid image file.`);
        continue;
      }
      const base = CT.slugify(path.basename(f.originalname, path.extname(f.originalname))).slice(0, 50) || "image";
      const outExt = meta.format === "jpeg" ? "jpg" : meta.format;
      const name = `${base}-${crypto.randomBytes(3).toString("hex")}.${outExt}`;
      let width = meta.width, height = meta.height, outBuffer;
      try {
        if (meta.format === "gif") {
          outBuffer = f.buffer; // keep animation; resizing would drop frames
        } else {
          let pipeline = sharp(f.buffer).rotate(); // auto-orient from EXIF, then strip all metadata by default
          if (meta.width > 2400 || meta.height > 2400) pipeline = pipeline.resize(2400, 2400, { fit: "inside", withoutEnlargement: true });
          if (meta.format === "jpeg") pipeline = pipeline.jpeg({ quality: 88, mozjpeg: true });
          else if (meta.format === "webp") pipeline = pipeline.webp({ quality: 88 });
          else pipeline = pipeline.png({ compressionLevel: 9 });
          const outInfo = await pipeline.toBuffer({ resolveWithObject: true });
          outBuffer = outInfo.data;
          width = outInfo.info.width; height = outInfo.info.height;
        }
      } catch (e) {
        flashErr(req, `${f.originalname}: could not process this image.`);
        continue;
      }
      // Object storage mode (see src/lib/storage.js): nothing touches local disk, so uploads
      // survive hosts (like Hostinger Business "Web App") that wipe local files on redeploy.
      if (storage.enabled()) await storage.putObject(storage.mediaKey(name), outBuffer, ALLOWED_IMG[outExt]);
      else fs.writeFileSync(path.join(uploadDir, name), outBuffer);
      db.prepare("INSERT INTO media(filename,original_name,mime,size,width,height,alt,created_at,user_id) VALUES(?,?,?,?,?,?,?,?,?)")
        .run(name, f.originalname.slice(0, 150), ALLOWED_IMG[outExt], outBuffer.length, width, height, "", D.now(), auth.currentUser(req).id);
      saved++;
    }
    if (saved) {
      D.logActivity(db, auth.currentUser(req), "media-upload", `${saved} file(s)`);
      flashOk(req, `Uploaded ${saved} image(s). Add alt text so they are accessible and SEO-friendly.`);
    }
    res.redirect("/admin/media");
  });

  router.post("/media/:id(\\d+)/alt", STAFF, (req, res) => {
    db.prepare("UPDATE media SET alt=? WHERE id=?").run((req.body.alt || "").trim().slice(0, 200), parseInt(req.params.id, 10));
    flashOk(req, "Alt text saved.");
    res.redirect(req.headers.referer || "/admin/media");
  });

  router.post("/media/:id(\\d+)/delete", STAFF, async (req, res) => {
    const mid = parseInt(req.params.id, 10);
    const r = db.prepare("SELECT * FROM media WHERE id=?").get(mid);
    if (!r) return res.status(404).end();
    const used = db.prepare("SELECT path FROM pages WHERE content_md LIKE ? OR og_image LIKE ?").all(`%${r.filename}%`, `%${r.filename}%`);
    if (used.length && !req.body.force) {
      flashErr(req, "This image is used on: " + used.map((u) => u.path).join(", ") + ". Remove it from those pages first, or tick \u201cdelete anyway\u201d.");
      return res.redirect("/admin/media");
    }
    if (storage.enabled()) { await storage.deleteObject(storage.mediaKey(r.filename)).catch(() => {}); }
    else { try { fs.unlinkSync(path.join(uploadDir, r.filename)); } catch (e) { /* already gone */ } }
    db.prepare("DELETE FROM media WHERE id=?").run(mid);
    D.logActivity(db, auth.currentUser(req), "media-delete", r.filename);
    flashOk(req, "Image deleted.");
    res.redirect("/admin/media");
  });

  // ----------------------------------------------------------------- menus
  router.get("/menus", ADMIN, (req, res) => {
    const items = db.prepare("SELECT * FROM menu_items ORDER BY location, sort_order, id").all();
    const groups = MENU_LOCATIONS.map(([k, label]) => [k, label, items.filter((i) => i.location === k)]);
    render(req, res, "menus", { groups });
  });

  router.post("/menus", ADMIN, (req, res) => {
    const f = req.body;
    const ids = [].concat(f.id || []);
    const labels = [].concat(f.label || []);
    const urls = [].concat(f.url || []);
    const locs = [].concat(f.location || []);
    const orders = [].concat(f.sort_order || []);
    const newTabs = [].concat(f.new_tab || []);
    const deletes = [].concat(f.delete || []);
    const errors = [];
    for (let i = 0; i < ids.length; i++) {
      const mid = ids[i];
      const label = (labels[i] || "").trim(), url_ = (urls[i] || "").trim(), loc = locs[i];
      if (!label && !url_) { if (mid !== "0") db.prepare("DELETE FROM menu_items WHERE id=?").run(mid); continue; }
      if (deletes[i] === "1" && mid !== "0") { db.prepare("DELETE FROM menu_items WHERE id=?").run(mid); continue; }
      if (!label || !(url_.startsWith("/") || /^https?:\/\//.test(url_)) || !MENU_LOCATIONS.some(([k]) => k === loc)) {
        errors.push(`Menu item \u201c${label || url_}\u201d needs a label and a URL starting with / or http(s)://.`);
        continue;
      }
      const order = intOr(orders[i], 100);
      const nt = newTabs[i] === "1" ? 1 : 0;
      if (mid === "0") db.prepare("INSERT INTO menu_items(location,label,url,sort_order,new_tab) VALUES(?,?,?,?,?)").run(loc, label, url_, order, nt);
      else db.prepare("UPDATE menu_items SET location=?,label=?,url=?,sort_order=?,new_tab=? WHERE id=?").run(loc, label, url_, order, nt, mid);
    }
    errors.forEach((e) => flashErr(req, e));
    if (!errors.length) flashOk(req, "Menus saved.");
    D.logActivity(db, auth.currentUser(req), "menus-save");
    res.redirect("/admin/menus");
  });

  // ------------------------------------------------- redirects and 404 log
  router.get("/redirects", ADMIN, (req, res) => {
    const [rows, pg] = paginate("SELECT * FROM redirects ORDER BY id DESC", [], 100, intOr(req.query.page, 1, 1, 99999));
    render(req, res, "redirects", { rows, pg, prefill: req.query.from || "" });
  });

  router.post("/redirects", ADMIN, (req, res) => {
    const f = req.body;
    const frm = "/" + (f.from_path || "").trim().replace(/^\/+/, "");
    const to = (f.to_url || "").trim();
    const code = f.code === "302" ? 302 : 301;
    if (!/^\/[^\s]*$/.test(frm) || frm.startsWith("/admin")) {
      flashErr(req, "\u201cFrom\u201d must be a path starting with / (not /admin).");
    } else if (!(to.startsWith("/") || /^https?:\/\//.test(to))) {
      flashErr(req, "\u201cTo\u201d must be a path starting with / or a full http(s):// URL.");
    } else if (CT.normalizePath(frm) === CT.normalizePath(to)) {
      flashErr(req, "A redirect cannot point to itself.");
    } else {
      try {
        db.prepare("INSERT INTO redirects(from_path,to_url,code,created_at) VALUES(?,?,?,?)").run(frm, to, code, D.now());
        db.prepare("DELETE FROM not_found WHERE path=?").run(frm);
        flashOk(req, "Redirect added.");
        D.logActivity(db, auth.currentUser(req), "redirect-add", `${frm} \u2192 ${to}`);
      } catch (e) {
        flashErr(req, "A redirect from that path already exists.");
      }
    }
    res.redirect("/admin/redirects");
  });

  router.post("/redirects/:id(\\d+)/:action", ADMIN, (req, res) => {
    const rid = parseInt(req.params.id, 10);
    if (req.params.action === "delete") db.prepare("DELETE FROM redirects WHERE id=?").run(rid);
    else if (req.params.action === "toggle") db.prepare("UPDATE redirects SET enabled=1-enabled WHERE id=?").run(rid);
    else return res.status(404).end();
    res.redirect("/admin/redirects");
  });

  router.get("/404s", STAFF, (req, res) => {
    const [rows, pg] = paginate("SELECT * FROM not_found ORDER BY hits DESC, last_seen DESC", [], 100, intOr(req.query.page, 1, 1, 99999));
    render(req, res, "notfound", { rows, pg });
  });

  router.post("/404s", STAFF, (req, res) => {
    if (req.body.clear === "all") { db.prepare("DELETE FROM not_found").run(); flashOk(req, "404 log cleared."); }
    else if (req.body.path) db.prepare("DELETE FROM not_found WHERE path=?").run(req.body.path);
    res.redirect("/admin/404s");
  });

  // -------------------------------------------------------------- keywords
  router.get("/keywords", STAFF, (req, res) => {
    handleKeywords(req, res);
  });
  router.post("/keywords", STAFF, upload.single("file"), auth.checkCsrf, (req, res) => {
    const act = req.body.action;
    if (act === "update") {
      const kid = parseInt(req.body.id, 10);
      let mpath = (req.body.mapped_path || "").trim();
      mpath = mpath ? CT.normalizePath(mpath) : "";
      let status = req.body.status || "mapped";
      if (!["mapped", "ignore", "planned"].includes(status)) status = "mapped";
      db.prepare("UPDATE keywords SET mapped_path=?, status=?, notes=? WHERE id=?")
        .run(mpath, status, (req.body.notes || "").trim().slice(0, 300), kid);
      flashOk(req, "Keyword updated.");
    } else if (act === "delete") {
      db.prepare("DELETE FROM keywords WHERE id=?").run(parseInt(req.body.id, 10));
      flashOk(req, "Keyword deleted.");
    } else if (act === "import") {
      let raw = req.body.paste || "";
      if (req.file) raw = req.file.buffer.toString("utf8").replace(/^\uFEFF/, "");
      const result = importKeywords(raw);
      flashOk(req, `Imported: ${result.added} new, ${result.updated} updated. New keywords start as \u201cplanned\u201d; map them to a page.`);
    }
    const qp = new URLSearchParams();
    for (const k of ["s", "status", "path", "check"]) if (req.query[k]) qp.set(k, req.query[k]);
    res.redirect("/admin/keywords" + (qp.toString() ? "?" + qp.toString() : ""));
  });

  function splitCsvLine(line) {
    // Minimal CSV splitter: handles quoted fields containing commas.
    const out = [];
    let cur = "", inQ = false;
    for (let i = 0; i < line.length; i++) {
      const c = line[i];
      if (inQ) {
        if (c === '"' && line[i + 1] === '"') { cur += '"'; i++; }
        else if (c === '"') inQ = false;
        else cur += c;
      } else if (c === '"') inQ = true;
      else if (c === ",") { out.push(cur); cur = ""; }
      else cur += c;
    }
    out.push(cur);
    return out;
  }

  function importKeywords(raw) {
    let added = 0, updated = 0;
    for (const line of raw.split("\n")) {
      if (!line.trim()) continue;
      const parts = (line.includes("\t") ? line.split("\t") : splitCsvLine(line)).map((p) => p.trim());
      if (!parts[0] || ["keyword", "keywords"].includes(parts[0].toLowerCase())) continue;
      const kw = parts[0].toLowerCase().slice(0, 120);
      const intent = parts[1] || "";
      const num = (i, isFloat) => {
        if (parts.length <= i || parts[i] === "") return null;
        const n = isFloat ? parseFloat(parts[i]) : parseInt(parts[i], 10);
        return Number.isNaN(n) ? null : n;
      };
      const score = num(2, false), vol = num(3, false), kd = num(4, false), cpc = num(5, true);
      const existing = db.prepare("SELECT 1 FROM keywords WHERE keyword=?").get(kw);
      if (existing) {
        db.prepare(`UPDATE keywords SET intent=?, score=COALESCE(?,score), volume=COALESCE(?,volume),
          kd=COALESCE(?,kd), cpc=COALESCE(?,cpc) WHERE keyword=?`).run(intent, score, vol, kd, cpc, kw);
        updated++;
      } else {
        db.prepare("INSERT INTO keywords(keyword,intent,score,volume,kd,cpc,mapped_path,status) VALUES(?,?,?,?,?,?,'','planned')")
          .run(kw, intent, score || 0, vol || 0, kd, cpc);
        added++;
      }
    }
    return { added, updated };
  }

  function handleKeywords(req, res) {
    const s = (req.query.s || "").trim().toLowerCase();
    const status = req.query.status || "";
    const qpath = req.query.path || "";
    const where = ["1=1"];
    const args = [];
    if (s) { where.push("keyword LIKE ?"); args.push(`%${s}%`); }
    if (status) { where.push("status=?"); args.push(status); }
    if (qpath) { where.push("mapped_path=?"); args.push(qpath); }
    const [rows, pg] = paginate(`SELECT * FROM keywords WHERE ${where.join(" AND ")} ORDER BY volume DESC, keyword`, args, 60, intOr(req.query.page, 1, 1, 99999));
    const check = req.query.check === "1";
    const coverage = {};
    if (check) {
      const cache = {};
      for (const r of rows) {
        if (r.status === "mapped" && r.mapped_path) {
          if (!(r.mapped_path in cache)) cache[r.mapped_path] = renderPageTextForKeywordCheck(r.mapped_path);
          coverage[r.id] = cache[r.mapped_path] !== null && cache[r.mapped_path].includes(r.keyword.toLowerCase());
        }
      }
    }
    const paths = db.prepare("SELECT path FROM pages ORDER BY path").all().map((p) => p.path)
      .concat(db.prepare("SELECT * FROM convert_values ORDER BY id").all().map((v) => core.valuePath(v.direction, v.value)));
    const totals = db.prepare("SELECT COUNT(*) c, COALESCE(SUM(volume),0) v FROM keywords WHERE status='mapped'").get();
    render(req, res, "keywords", { rows, pg, s, status, path: qpath, check, coverage, paths, totals });
  }

  function renderPageTextForKeywordCheck(urlPath) {
    // Render the page's markdown fields directly (title + description + body) rather than a real HTTP round-trip.
    const row = core.getPage(db, urlPath) || (() => {
      const m = core.VALUE_SLUG_RE.exec((urlPath || "").replace(/^\/convert\//, "").replace(/\/$/, ""));
      return null;
    })();
    if (row) {
      const s = D.getSettings(db);
      const title = core.pageTitle(s, row);
      const desc = row.meta_description || "";
      const body = CT.plain(CT.renderMd(row.content_md).html);
      const faq = core.parseFaq(row.faq_json).map((f) => f.q + " " + f.a).join(" ");
      return `${title} ${desc} ${row.intro} ${body} ${faq}`.toLowerCase();
    }
    // value pages
    const m = /^\/convert\/([^/]+)\/?$/.exec(urlPath);
    if (m) {
      const parsed = core.parseValueSlug(m[1]);
      if (parsed) {
        const vrow = core.getValueRow(db, ...parsed);
        if (vrow) {
          const f = core.valueFacts(vrow);
          const { title, desc, h1 } = core.valueSeoDefaults(f);
          return `${vrow.seo_title || title} ${vrow.meta_description || desc} ${h1} ${vrow.notes_md || ""}`.toLowerCase();
        }
      }
    }
    return null;
  }

  router.get("/keywords/export.csv", STAFF, (req, res) => {
    const rows = db.prepare("SELECT * FROM keywords ORDER BY volume DESC").all();
    const esc = (v) => {
      const s = v === null || v === undefined ? "" : String(v);
      return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
    };
    const lines = ["keyword,intent,score,volume,kd,cpc,mapped_path,status,notes"];
    for (const r of rows) lines.push([r.keyword, r.intent, r.score, r.volume, r.kd, r.cpc, r.mapped_path, r.status, r.notes].map(esc).join(","));
    res.set("Content-Disposition", "attachment; filename=keywords.csv").type("text/csv").send(lines.join("\n"));
  });

  // -------------------------------------------------------------- messages
  router.get("/messages", STAFF, (req, res) => {
    const view = req.query.view === "spam" ? "spam" : "inbox";
    const where = view === "spam" ? "is_spam=1" : "is_spam=0";
    const [rows, pg] = paginate(`SELECT * FROM messages WHERE ${where} ORDER BY id DESC`, [], 50, intOr(req.query.page, 1, 1, 99999));
    render(req, res, "messages", { rows, pg, view });
  });

  router.get("/messages/:id(\\d+)", STAFF, (req, res) => {
    const mid = parseInt(req.params.id, 10);
    const m = db.prepare("SELECT * FROM messages WHERE id=?").get(mid);
    if (!m) return res.status(404).end();
    db.prepare("UPDATE messages SET is_read=1 WHERE id=?").run(mid);
    render(req, res, "message_view", { m });
  });

  router.post("/messages/:id(\\d+)", STAFF, (req, res) => {
    const mid = parseInt(req.params.id, 10);
    const m = db.prepare("SELECT * FROM messages WHERE id=?").get(mid);
    if (!m) return res.status(404).end();
    const a = req.body.action;
    if (a === "delete") { db.prepare("DELETE FROM messages WHERE id=?").run(mid); flashOk(req, "Message deleted."); return res.redirect("/admin/messages"); }
    if (a === "spam") db.prepare("UPDATE messages SET is_spam=1-is_spam WHERE id=?").run(mid);
    if (a === "unread") { db.prepare("UPDATE messages SET is_read=0 WHERE id=?").run(mid); return res.redirect("/admin/messages"); }
    res.redirect(`/admin/messages/${mid}`);
  });

  // ----------------------------------------------------------- users / profile
  function validUsername(n) {
    return /^[A-Za-z0-9_.-]{3,32}$/.test(n || "");
  }

  router.get("/users", ADMIN, (req, res) => {
    render(req, res, "users", { rows: db.prepare("SELECT * FROM users ORDER BY username").all() });
  });

  router.get("/users/new", ADMIN, (req, res) => showUserEditor(req, res, 0));
  router.get("/users/:id(\\d+)/edit", ADMIN, (req, res) => showUserEditor(req, res, parseInt(req.params.id, 10)));

  function showUserEditor(req, res, uid) {
    const row = uid ? db.prepare("SELECT * FROM users WHERE id=?").get(uid) : null;
    if (uid && !row) return res.status(404).end();
    const u = row || { id: 0, username: "", email: "", role: "editor" };
    render(req, res, "user_edit", { u });
  }

  router.post("/users/new", ADMIN, (req, res) => saveUser(req, res, 0));
  router.post("/users/:id(\\d+)/edit", ADMIN, (req, res) => saveUser(req, res, parseInt(req.params.id, 10)));

  function saveUser(req, res, uid) {
    const row = uid ? db.prepare("SELECT * FROM users WHERE id=?").get(uid) : null;
    if (uid && !row) return res.status(404).end();
    const u = row || { id: 0, username: "", email: "", role: "editor" };
    const f = req.body;
    const name = (f.username || "").trim(), email = (f.email || "").trim(), role0 = f.role || "editor", pw = f.password || "";
    const errors = [];
    if (!uid && !validUsername(name)) errors.push("Username must be 3\u201332 characters: letters, numbers, dot, dash or underscore.");
    if (!uid && db.prepare("SELECT 1 FROM users WHERE username=?").get(name)) errors.push("That username is taken.");
    if (email && !EMAIL_RE.test(email)) errors.push("Enter a valid email address or leave it blank.");
    let role = role0 === "admin" ? "admin" : "editor";
    if ((!uid || pw) && pw.length < 10) errors.push("Password must be at least 10 characters.");
    if (uid && row.role === "admin" && role !== "admin" && db.prepare("SELECT COUNT(*) c FROM users WHERE role='admin'").get().c <= 1) {
      errors.push("You cannot demote the only administrator.");
    }
    if (errors.length) {
      errors.forEach((e) => flashErr(req, e));
      res.status(422);
      return render(req, res, "user_edit", { u: Object.assign({}, u, { username: name || u.username, email, role }) });
    }
    if (uid) {
      db.prepare("UPDATE users SET email=?, role=? WHERE id=?").run(email, role, uid);
      if (pw) db.prepare("UPDATE users SET password_hash=?, must_change_pw=1 WHERE id=?").run(auth.hashPw(pw), uid);
    } else {
      const info = db.prepare("INSERT INTO users(username,email,password_hash,role,must_change_pw,created_at) VALUES(?,?,?,?,1,?)")
        .run(name, email, auth.hashPw(pw), role, D.now());
      uid = info.lastInsertRowid;
    }
    D.logActivity(db, auth.currentUser(req), "user-save", name || u.username);
    flashOk(req, pw ? "User saved. They must set a new password at first sign-in." : "User saved.");
    res.redirect("/admin/users");
  }

  router.post("/users/:id(\\d+)/delete", ADMIN, (req, res) => {
    const uid = parseInt(req.params.id, 10);
    const me = auth.currentUser(req);
    const r = db.prepare("SELECT * FROM users WHERE id=?").get(uid);
    if (!r) return res.status(404).end();
    if (uid === me.id) flashErr(req, "You cannot delete your own account.");
    else if (r.role === "admin" && db.prepare("SELECT COUNT(*) c FROM users WHERE role='admin'").get().c <= 1) flashErr(req, "You cannot delete the only administrator.");
    else {
      db.prepare("DELETE FROM users WHERE id=?").run(uid);
      D.logActivity(db, me, "user-delete", r.username);
      flashOk(req, "User deleted.");
    }
    res.redirect("/admin/users");
  });

  router.get("/profile", STAFF, (req, res) => render(req, res, "profile", {}));

  router.post("/profile", STAFF, (req, res) => {
    const me = auth.currentUser(req);
    const f = req.body;
    const errors = [];
    const email = (f.email || "").trim();
    if (email && !EMAIL_RE.test(email)) errors.push("Enter a valid email address or leave it blank.");
    const newPw = f.new_password || "";
    if (newPw) {
      if (!auth.verifyPw(me.password_hash, f.current_password || "")) errors.push("Your current password is incorrect.");
      if (newPw.length < 10) errors.push("New password must be at least 10 characters.");
      if (newPw !== f.confirm_password) errors.push("The new passwords do not match.");
      if (newPw === f.current_password) errors.push("Choose a password different from the current one.");
    }
    if (me.must_change_pw && !newPw) errors.push("You must choose a new password before continuing.");
    if (errors.length) {
      errors.forEach((e) => flashErr(req, e));
      res.status(422);
      return render(req, res, "profile", {});
    }
    db.prepare("UPDATE users SET email=? WHERE id=?").run(email, me.id);
    if (newPw) {
      db.prepare("UPDATE users SET password_hash=?, must_change_pw=0 WHERE id=?").run(auth.hashPw(newPw), me.id);
      D.logActivity(db, me, "password-change");
    }
    flashOk(req, "Profile saved.");
    res.redirect(newPw ? "/admin/" : "/admin/profile");
  });

  // -------------------------------------------------------------- settings
  const SETTING_FIELDS = ["site_name", "tagline", "base_url", "publisher_name", "contact_email", "smtp_notify_to", "default_og_image",
    "twitter_handle", "ga_id", "gsc_verification", "bing_verification", "footer_text", "head_code", "footer_code", "robots_txt",
    "chart_kj", "chart_cal"];

  router.get("/settings", ADMIN, (req, res) => {
    const s = D.getSettings(db);
    if (!s.chart_kj) s.chart_kj = core.defaultChartText(KJ_CHART_FALLBACK);
    if (!s.chart_cal) s.chart_cal = core.defaultChartText(CAL_CHART_FALLBACK);
    render(req, res, "settings", { s });
  });

  router.post("/settings", ADMIN, (req, res) => {
    const f = {};
    for (const k of SETTING_FIELDS) f[k] = (req.body[k] || "").trim();
    f.head_code = req.body.head_code || "";
    f.footer_code = req.body.footer_code || "";
    f.robots_txt = (req.body.robots_txt || "").replace(/\r\n/g, "\n").trim();
    f.chart_kj = (req.body.chart_kj || "").replace(/\r\n/g, "\n").trim();
    f.chart_cal = (req.body.chart_cal || "").replace(/\r\n/g, "\n").trim();
    const errors = [];
    f.base_url = f.base_url.replace(/\/$/, "");
    if (!/^https?:\/\/[^\s/]+$/.test(f.base_url)) errors.push("Site URL must look like https://kjtocal.org (no path, no trailing slash).");
    if (!f.site_name) errors.push("Site name is required.");
    if (f.ga_id && !/^(G|GT|AW|UA)-[A-Z0-9-]{4,20}$/.test(f.ga_id)) errors.push("Google Analytics ID should look like G-XXXXXXXXXX.");
    if (f.twitter_handle && !/^@?[A-Za-z0-9_]{1,15}$/.test(f.twitter_handle)) errors.push("X/Twitter handle is not valid.");
    for (const k of ["gsc_verification", "bing_verification"]) {
      if (f[k] && !/^[A-Za-z0-9_-]{10,100}$/.test(f[k])) errors.push(`${k.replace(/_/g, " ")} token should contain only letters, numbers, - and _.`);
    }
    for (const k of ["contact_email", "smtp_notify_to"]) {
      if (f[k] && !EMAIL_RE.test(f[k])) errors.push(`${k.replace(/_/g, " ")} is not a valid email address.`);
    }
    for (const [key, fb] of [["chart_kj", KJ_CHART_FALLBACK], ["chart_cal", CAL_CHART_FALLBACK]]) {
      if (f[key]) {
        const parsed = core.parseChartSetting(f[key], null);
        if (!parsed || !parsed.length) errors.push(`${key} is invalid. Use lines like: Title | 1, 2, 3`);
      }
    }
    if (errors.length) {
      errors.forEach((e) => flashErr(req, e));
      res.status(422);
      return render(req, res, "settings", { s: Object.assign({}, D.getSettings(db), f) });
    }
    for (const [k, v] of Object.entries(f)) D.setSetting(db, k, v);
    D.logActivity(db, auth.currentUser(req), "settings-save");
    flashOk(req, "Settings saved.");
    res.redirect("/admin/settings");
  });

  // ----------------------------------------------------------------- tools
  function resolveInternal(p) {
    const base = p.replace(/[?#].*$/, "");
    if (base.startsWith("/img/") || base.startsWith("/css/") || base.startsWith("/js/") || base.startsWith("/fonts/")) {
      const rel = base.replace(/^\/(img|css|js|fonts)\//, "$1/");
      return fs.existsSync(path.join(__dirname, "..", "..", "public", rel));
    }
    if (base.startsWith("/media/")) {
      const filename = base.slice("/media/".length);
      return storage.enabled()
        ? db.prepare("SELECT 1 FROM media WHERE filename=?").get(filename) !== undefined
        : fs.existsSync(path.join(uploadDir, filename));
    }
    if (["/sitemap.xml", "/robots.txt", "/favicon.ico"].includes(base)) return true;
    const n = CT.normalizePath(base);
    if (core.getPage(db, n)) return true;
    const m = /^\/convert\/([^/]+)\/$/.exec(n);
    if (m) {
      const pv = core.parseValueSlug(m[1]);
      if (pv && core.getValueRow(db, ...pv)) return true;
    }
    return !!db.prepare("SELECT 1 FROM redirects WHERE enabled=1 AND (from_path=? OR from_path=?)").get(base, n);
  }

  function scanLinks() {
    const broken = [];
    for (const p of db.prepare("SELECT * FROM pages").all()) {
      const blob = [p.content_md || "", p.intro || "", p.faq_json || "", p.related || ""].join("\n");
      const links = new Set(CT.internalLinks(blob));
      for (const l of (p.related || "").split("\n")) if (l.trim()) links.add(CT.normalizePath(l));
      for (const l of Array.from(links).sort()) {
        if (!resolveInternal(l)) broken.push([p.path, l, `/admin/pages/${p.id}/edit`]);
      }
    }
    for (const v of db.prepare("SELECT * FROM convert_values").all()) {
      for (const l of CT.internalLinks(v.notes_md || "")) {
        if (!resolveInternal(l)) broken.push([core.valuePath(v.direction, v.value), l, `/admin/values/${v.id}/edit`]);
      }
    }
    for (const m of db.prepare("SELECT * FROM menu_items").all()) {
      if (m.url.startsWith("/") && !resolveInternal(m.url)) broken.push([`menu: ${m.label}`, m.url, "/admin/menus"]);
    }
    return broken;
  }

  router.get("/tools", ADMIN, (req, res) => render(req, res, "tools", { storageEnabled: storage.enabled() }));

  router.get("/tools/links", STAFF, (req, res) => render(req, res, "links", { broken: scanLinks() }));

  router.get("/tools/audit", STAFF, (req, res) => {
    const rows = [];
    const titles = {};
    const allPages = db.prepare("SELECT * FROM pages ORDER BY path").all();
    for (const p of allPages) {
      const key = (p.seo_title || p.title).trim().toLowerCase();
      (titles[key] = titles[key] || []).push(p.path);
    }
    for (const p of allPages) {
      const issues = core.analysePage(p);
      const key = (p.seo_title || p.title).trim().toLowerCase();
      const dups = titles[key] || [];
      if (dups.length > 1) issues.push(["bad", "Duplicate SEO title also used on " + dups.filter((d) => d !== p.path).join(", ")]);
      const inbound = db.prepare("SELECT COUNT(*) c FROM pages WHERE id!=? AND (content_md LIKE ? OR related LIKE ?)")
        .get(p.id, `%(${p.path})%`, `%${p.path}%`).c;
      const menu = db.prepare("SELECT COUNT(*) c FROM menu_items WHERE url=?").get(p.path).c;
      if (p.path !== "/" && inbound + menu === 0) issues.push(["warn", "Orphan page: no other page or menu links to it."]);
      rows.push([p, issues, CT.wordCount(p.content_md)]);
    }
    render(req, res, "audit", { rows });
  });

  router.get("/tools/backup.db", ADMIN, (req, res) => {
    const tmp = path.join(require("os").tmpdir(), `kjtocal-backup-${crypto.randomBytes(6).toString("hex")}.db`);
    db.backup(tmp).then(() => {
      D.logActivity(db, auth.currentUser(req), "backup-download");
      res.download(tmp, `kjtocal-backup-${new Date().toISOString().slice(0, 10)}.db`, (err) => {
        fs.unlink(tmp, () => {});
      });
    }).catch((e) => {
      res.status(500).end("Backup failed: " + e.message);
    });
  });

  router.get("/tools/export.json", ADMIN, (req, res) => {
    const data = {
      exported_at: D.now(), settings: D.getSettings(db),
      pages: db.prepare("SELECT * FROM pages ORDER BY path").all(),
      values: db.prepare("SELECT * FROM convert_values").all(),
      menus: db.prepare("SELECT * FROM menu_items").all(),
      redirects: db.prepare("SELECT * FROM redirects").all(),
      keywords: db.prepare("SELECT * FROM keywords").all(),
    };
    D.logActivity(db, auth.currentUser(req), "content-export");
    res.set("Content-Disposition", `attachment; filename=kjtocal-content-${new Date().toISOString().slice(0, 10)}.json`);
    res.type("application/json").send(JSON.stringify(data, null, 2));
  });

  router.get("/activity", ADMIN, (req, res) => {
    const [rows, pg] = paginate("SELECT * FROM activity ORDER BY id DESC", [], 100, intOr(req.query.page, 1, 1, 99999));
    render(req, res, "activity", { rows, pg });
  });

  return router;
};
