#!/usr/bin/env node
"use strict";
/** Command-line helpers.  Usage:  node manage.js <command>
 *
 *   create-admin USERNAME PASSWORD   create an administrator
 *   reset-password USERNAME PASSWORD set a new password for an existing user
 *   list-users                       show all users
 *   check                            verify the database, content links and conversion maths
 */
const { createApp } = require("./app");
const D = require("./src/lib/db");
const auth = require("./src/lib/auth");

function usage() {
  console.log(require("fs").readFileSync(__filename, "utf8").split("\n").slice(1, 8).join("\n").replace(/^\/\*\*?|\*\/$/g, ""));
}

async function main(argv) {
  const cmd = argv[2];
  if (!cmd || cmd === "-h" || cmd === "--help") { usage(); return 0; }
  const app = createApp();
  const db = app.locals.db;

  if (cmd === "create-admin" && argv[4]) {
    const [, , , username, password] = argv;
    if (password.length < 10) { console.error("Password must be at least 10 characters."); return 1; }
    if (db.prepare("SELECT 1 FROM users WHERE username=?").get(username)) { console.error("That username already exists."); return 1; }
    db.prepare("INSERT INTO users(username,email,password_hash,role,must_change_pw,created_at) VALUES(?,?,?,?,0,?)")
      .run(username, "", auth.hashPw(password), "admin", D.now());
    console.log("Administrator created.");
    return 0;
  }
  if (cmd === "reset-password" && argv[4]) {
    const [, , , username, password] = argv;
    if (password.length < 10) { console.error("Password must be at least 10 characters."); return 1; }
    if (!db.prepare("SELECT 1 FROM users WHERE username=?").get(username)) { console.error("No such user."); return 1; }
    db.prepare("UPDATE users SET password_hash=?, must_change_pw=0 WHERE username=?").run(auth.hashPw(password), username);
    console.log("Password updated.");
    return 0;
  }
  if (cmd === "list-users") {
    for (const u of db.prepare("SELECT username, role, last_login FROM users ORDER BY username").all()) {
      console.log(`${u.username.padEnd(20)} ${u.role.padEnd(8)} last sign-in: ${u.last_login || "never"}`);
    }
    return 0;
  }
  if (cmd === "check") {
    const C = require("./src/lib/converter");
    if (C.fmt(C.kjToKcal(2000)) !== "478.01" || C.fmt(C.kcalToKj(2000)) !== "8,368") {
      console.error("Conversion maths check FAILED"); return 1;
    }
    console.log("Conversion maths OK.");
    console.log("Pages:", db.prepare("SELECT COUNT(*) c FROM pages").get().c, "| Value pages:", db.prepare("SELECT COUNT(*) c FROM convert_values").get().c);
    return 0;
  }
  usage();
  return 2;
}

main(process.argv).then((code) => process.exit(code)).catch((e) => { console.error(e); process.exit(1); });
