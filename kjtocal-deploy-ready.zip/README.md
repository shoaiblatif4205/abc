# kjtocal.org — Node.js edition (Express / EJS / SQLite)

This is a full rewrite of the kjtocal.org site and admin CMS in **Node.js**, built specifically so it
deploys on hosts that only support JavaScript frameworks — including **Hostinger's "Web App" tool**,
which lists Express as a supported framework. Functionally it is a line-for-line port of the original
Python/Flask build: the same 24 written pages, the same 35 generated `/convert/` value pages, the same
converter maths (exact `1 kcal = 4.184 kJ`), and the same admin panel (pages, value pages, media,
menus, redirects, 404 log, keyword tracker, SEO audit, link checker, users, settings, backup/export).

## Quick start (local)

```bash
npm install
KJ_ENV=development node app.js      # http://localhost:5000  (admin: http://localhost:5000/admin/)
```

`KJ_ENV=development` turns off the cookie's `Secure` flag so sign-in works over plain `http://localhost`
(browsers refuse `Secure` cookies without HTTPS). Do not use it in production.

On first run the database is created and seeded, and an administrator is created. If you did not set
`ADMIN_PASSWORD`, a random password is **printed in the console** and saved to
`instance/first-run-admin.txt`. You are forced to change it at first sign-in. Delete that file afterwards.

Account helpers: `node manage.js create-admin NAME PASSWORD`, `reset-password NAME PASSWORD`,
`list-users`, `check`.

## Deploying on Hostinger Business hosting (full guide)

This is the main path this rewrite was built for — Hostinger's shared/Business "Web App" tool rejected
the original Python build ("Unsupported framework"), but it understands Node/Express.

**One thing to know before you start:** Business hosting's Node.js environment does not guarantee that
files written to local disk survive a redeploy or restart — only your `package.json`/source files and
environment variables are guaranteed to persist, not runtime-written data. That matters here because the
database (`instance/kjtocal.db`) and any images you upload through the admin panel are, by default,
ordinary local files. The sections below cover both the plain setup (simplest, but at some risk of
losing admin-panel changes on a redeploy) and the recommended setup with free object storage added
(removes that risk entirely, and still deploys in about the same amount of time).

### Part A — Deploy the app

1. **Log into hPanel** and go to **Websites → Add Website → Deploy Web App** (sometimes just labelled
   **Node.js** depending on your account region).
2. **Choose how to provide the files.** You have this project as a folder, not a GitHub repo, so pick
   **Upload your website files** (wording varies: "Upload ZIP", "File Manager", etc.) and upload the
   project's zip file.
3. **Check the file structure after upload.** `app.js`, `package.json`, `src/`, `views/` and `public/`
   need to sit directly in the app's root folder — not nested one level deeper inside an extra
   `kjtocal-node/` folder. This is the single most common reason a deploy wizard fails to detect the
   app. If you see a nested folder in Hostinger's file manager, move everything up one level.
4. **Framework:** choose **Express** if it's offered (it should auto-detect from `package.json`). If
   only **Other** is offered: set **Entry file** to `app.js` and leave **Output directory** blank (this
   is a server, not a static site build).
5. **Node.js version:** 18 or higher — 20 is a safe default.
6. **Install dependencies.** Hostinger usually runs `npm install` automatically once it sees
   `package.json`. If there's a manual "Install" button, click it. First install takes a little longer
   than usual because `better-sqlite3` and `sharp` compile small native components — this is normal.
7. **Environment variables.** In the app's dashboard, find **Environment Variables** and add:

   | Key | Value |
   |---|---|
   | `KJ_ENV` | `production` |
   | `ADMIN_USERNAME` | `admin` |
   | `ADMIN_PASSWORD` | *(a strong password you choose yourself — see note below)* |
   | `CANONICAL_HOST` | `kjtocal.org` |
   | `TRUSTED_PROXIES` | `1` |

   Don't set `PORT` — Hostinger assigns this itself. Setting `ADMIN_PASSWORD` yourself matters more here
   than on most hosts: the alternative (a random password written to a file on disk) is exactly the kind
   of thing that can be lost if local storage doesn't persist.
8. **Deploy and start the app.** Wait for the build to finish, then confirm it shows **Running** and the
   temporary URL Hostinger gives you (something like `*.hostingersite.com`) loads correctly.
9. **Connect your domain.** In the app's settings, find **Domain** and connect `kjtocal.org`. If the
   domain isn't already pointed at Hostinger, go to **Domains → DNS Zone** and point the A record at your
   hosting IP — hPanel shows you exactly what's needed once you link the domain to the app.
10. **Enable SSL** for the domain (hPanel usually offers a free one-click Let's Encrypt certificate).
11. Visit `https://kjtocal.org/admin/login` and sign in with the credentials from step 7.

At this point the site is fully live. If you're comfortable with the small risk described above — or you
mainly care about the converter and the 59 built-in pages, and rarely touch the admin panel afterwards —
you can stop here.

### Part B — Make it fully persistent (recommended, 10 more minutes)

This adds free S3-compatible object storage so that uploaded images, the database, and your session
login all survive redeploys automatically — no manual backup/restore needed. The app already has this
built in; it only activates once the environment variables below are set.

**Why Cloudflare R2:** free tier (10 GB storage, no egress fees), S3-compatible, and the setup below
takes about five minutes. Any other S3-compatible provider works too (Backblaze B2, AWS S3,
DigitalOcean Spaces, Wasabi) — just adjust the endpoint/region accordingly.

1. **Create a Cloudflare account** (free) at [cloudflare.com](https://cloudflare.com) if you don't have
   one, then go to **R2 Object Storage** in the dashboard.
2. **Create a bucket** — name it `kjtocal` (or anything; you'll reference it by name in an env var).
3. **Create an API token**: in R2, go to **Manage R2 API Tokens → Create API Token**. Give it
   **Object Read & Write** permission, scoped to your new bucket. Save the **Access Key ID** and
   **Secret Access Key** it shows you — this is the only time the secret is displayed.
4. **Note your account's R2 endpoint**, shown on the R2 overview page — it looks like
   `https://<account-id>.r2.cloudflarestorage.com`.
5. *(Optional, for faster public image URLs instead of signed links)* Under your bucket's **Settings**,
   enable **Public Access** and note the public URL it gives you (or connect a custom subdomain).
   Skip this and the app will use secure, auto-expiring signed links instead — works fine either way.
6. **Back in Hostinger's environment variables** for the app, add:

   | Key | Value |
   |---|---|
   | `S3_ENDPOINT` | `https://<account-id>.r2.cloudflarestorage.com` |
   | `S3_BUCKET` | `kjtocal` |
   | `S3_ACCESS_KEY_ID` | *(from step 3)* |
   | `S3_SECRET_ACCESS_KEY` | *(from step 3)* |
   | `S3_REGION` | `auto` |
   | `S3_PUBLIC_BASE_URL` | *(the public URL from step 5, only if you enabled it — otherwise leave blank)* |

7. **Redeploy or restart the app** so it picks up the new variables.

That's it — nothing else to configure. From now on:
- Every image uploaded through **Media library** goes straight to R2, never to local disk.
- The database is backed up to R2 automatically every 10 minutes while the app runs, and once more on
  every clean shutdown.
- If a redeploy wipes local storage, the app notices the database file is missing **the moment it next
  starts up** and restores it from the last R2 backup automatically, before anything else happens — your
  pages, settings, keyword mappings and uploaded images are all back without you doing anything.
- Your admin login session also survives, because the session-signing key is backed up the same way.

Check it worked: open **Admin → Backup & export** — it should show a green banner confirming object
storage is configured, instead of the red warning about local-only storage.

**One gap worth knowing:** the automatic backup runs periodically (every 10 minutes by default) and on
clean shutdowns, not after literally every single edit. If a host kills the process abruptly between
backups (rare, but possible on any shared host), edits made in that window could be lost. For anything
important, **Admin → Backup & export → Download database backup** still gives you an instant, complete
local copy any time you want extra peace of mind.

### Part C — VPS (full control, no ephemeral-storage concerns at all)

If you'd rather avoid the object-storage dependency entirely, a Hostinger **VPS** plan (same account,
different product) gives you a real persistent filesystem. Use the systemd + nginx setup under `deploy/`:

```bash
ssh root@your-vps-ip
apt update && apt install -y nodejs npm nginx certbot python3-certbot-nginx build-essential

scp -r kjtocal-node root@your-vps-ip:/srv/kjtocal   # from your local machine
cd /srv/kjtocal
npm install --omit=dev
cp .env.example .env
nano .env   # fill in ADMIN_PASSWORD, CANONICAL_HOST=kjtocal.org, etc. (S3_* can stay blank)

cp deploy/kjtocal.service /etc/systemd/system/
systemctl enable --now kjtocal
systemctl status kjtocal        # should show "active (running)"

cp deploy/nginx.conf /etc/nginx/sites-available/kjtocal.org
ln -s /etc/nginx/sites-available/kjtocal.org /etc/nginx/sites-enabled/
nginx -t && systemctl reload nginx

certbot --nginx -d kjtocal.org -d www.kjtocal.org
```

An alternative to systemd is **PM2** — `npm i -g pm2 && pm2 start deploy/ecosystem.config.js`. Keep
`instances: 1` (already set): this app uses SQLite and a file-based session store, neither of which is
built for PM2's cluster mode across multiple processes sharing one port.

### Docker

```bash
docker build -t kjtocal .
docker run -d -p 3000:3000 -v kj-data:/app/instance --env-file .env kjtocal
```
*(Not build-tested in this environment — no Docker available here — but the image follows the same
pattern as any standard Node/Express Dockerfile: install deps, copy source, run as a non-root user, keep
`instance/` on a volume. On Docker, a persistent volume already solves the storage problem, so `S3_*` is
optional — only worth adding if you want off-host backups too.)*

### Railway / Render

Both auto-detect Node from `package.json` and run `npm install && npm start`. Set the same environment
variables as above, deploy, then point `kjtocal.org`'s DNS at the URL they give you. Both platforms have
their own persistent-volume options as an alternative to `S3_*`, if you'd rather use those.

## Environment variables

| Variable | Purpose |
|---|---|
| `KJ_ENV` | `production` (default) enables Secure cookies. Serve over HTTPS. |
| `PORT` | Port to listen on (default `5000`; most hosts set this for you). |
| `SECRET_KEY` | Optional. Otherwise generated once into `instance/secret.key`, shared safely across concurrently-starting processes. |
| `KJ_INSTANCE` | Optional path for data, to keep it outside the code folder. |
| `ADMIN_USERNAME` / `ADMIN_PASSWORD` | Only used when no users exist yet. |
| `TRUSTED_PROXIES` | `1` behind nginx/Hostinger's proxy, so real client IPs (for rate limits) and HTTPS are detected. |
| `CANONICAL_HOST` | Redirects `www.` and other hosts to `kjtocal.org`. |
| `S3_ENDPOINT`, `S3_BUCKET`, `S3_ACCESS_KEY_ID`, `S3_SECRET_ACCESS_KEY`, `S3_REGION` | Optional. Set all five to turn on S3-compatible object storage for uploads and automatic database backup/restore — see "Deploying on Hostinger Business hosting" above. Leave blank for local-disk-only (the default). |
| `S3_PUBLIC_BASE_URL` | Optional. Serve uploaded images via a direct public URL instead of a signed one (only if your bucket is public). |
| `S3_BACKUP_INTERVAL_MINUTES` | Optional. How often to back the database up to object storage (default `10`). |

Copy `.env.example` to `.env` and the app loads it automatically (real environment variables from your
host always take precedence over `.env`).

## What is in the admin panel

Identical feature set to the Python build:

| Area | What you can do |
|---|---|
| **Pages & guides** | Markdown editor with toolbar and live preview; SERP preview and length counters; focus-keyword checks; FAQ (accordion + FAQPage schema); related links; converter defaults; draft/published/**scheduled** (UTC); noindex; canonical override; social image; duplicate; bulk publish/draft/delete; **revision history with restore**; renaming a URL adds a 301 automatically. |
| **Value pages** | The 35 pages under `/convert/`. Add any value (bulk add supported); the answer, working, nearby table and FAQ are generated from the exact factor. Add a note per value. |
| **Media** | Upload PNG/JPG/WebP/GIF (validated with `sharp`, resized to 2400 px, EXIF/metadata stripped), alt text, picker inside the editor. SVG is refused on purpose (XSS risk). |
| **Keywords** | Your 100 keywords, mapped to pages by intent. Import/export CSV, remap, and **Check coverage**: confirms the exact phrase appears on the live page. |
| **SEO audit / Link checker** | Title/description length, keyword placement, duplicate titles, orphan pages, broken internal links. |
| **Menus, Redirects, 404 log** | Edit header/footer links; 301/302 redirects; see missing URLs and turn them into redirects. |
| **Messages** | Contact-form inbox with spam folder. Honeypot and rate limiting are built in. |
| **Users** | Administrator and Editor roles. Editors cannot delete pages or touch settings, menus, redirects, users. |
| **Settings** | Site details, Analytics/Search Console/Bing tokens, robots.txt, chart value lists, custom head/footer code. |
| **Backup & export** | Consistent database download (`better-sqlite3`'s native `.backup()`) and JSON content export. Shows whether S3-compatible object storage is configured, and explains what that does if not. |

## Accuracy: how the numbers are guaranteed

- One definition drives everything: **1 cal = 4.184 J exactly, so 1 kcal = 4.184 kJ**. Conversions run
  through joules using `decimal.js`, mirroring the server-side `Decimal` arithmetic from the Python build.
- The in-browser converter (`public/js/site.js`) is carried over unchanged from the original build and
  produces byte-identical output to the server for every conversion — this was verified across 10,832
  conversions during the Python build and the underlying JS file has not changed.
- Content (the 24 pages' copy, FAQs, value-page notes) was exported once from the working, tested Python
  version into `src/data/seed-content.json` — the words on the page are identical between both builds;
  only the code that serves them was rewritten.

## Tests

```bash
node app.js &            # start the app first (a test suite needs a live server)
node tests/crawl.js              # all 59 sitemap URLs: status, one H1, unique title/description within
                                  #   length limits, correct canonical, valid JSON-LD, no broken links
node tests/keywords.js           # all 92 non-typo keywords appear on their mapped page
node tests/concurrent_boot.js    # 6 processes booting at once on an empty install: no crash, no double
                                  #   seeding, one shared session-signing key (doesn't need a live server)
```

`run_tests.sh` runs all three against `BASE_URL` (defaults to `http://localhost:5091`; start the app on
that port first, or pass `BASE_URL=http://localhost:PORT`).

Admin panel functionality (login, CSRF, forced password change, page CRUD with revisions, value pages,
media upload, keyword coverage, settings, users, redirects, 404 log, link checker, SEO audit) was
verified with a Playwright-driven browser session covering the full admin workflow end to end; all
checks passed against this build.

The S3-compatible storage layer (`src/lib/storage.js`) was verified against a local S3-compatible test
server (`s3rver`, a dev dependency — not needed in production): direct put/get/delete, a real image
upload through the admin HTTP endpoint landing in the bucket instead of on local disk and being served
correctly via a signed redirect, and — the scenario this feature exists for — deleting the entire local
`instance/` folder (simulating a host wiping local storage on redeploy) and confirming the app restores
the database, all 24 pages, the admin user, and the session-signing key automatically on next boot, with
no manual steps. The full local-disk code path was also re-verified with `S3_*` unset, to confirm
identical behaviour to before this feature existed.

## Differences from the Python/Flask version

Functionally none — same routes, same URL structure, same admin capabilities, same content, same maths.
Implementation differences worth knowing about:

- **Templating**: EJS instead of Jinja2. Shared header/footer are done via `include()` partials rather
  than `{% extends %}` block inheritance; admin form widgets (`field`, `area`, `pager`, etc.) are plain
  JS functions in `src/lib/adminUi.js` rather than Jinja macros.
- **Database**: `better-sqlite3` (synchronous) instead of Python's `sqlite3`. Concurrent-safe first-boot
  seeding and admin-account creation use SQLite's `BEGIN IMMEDIATE` (via `db.transaction(fn).immediate()`)
  to serialise the "already set up?" check against the insert across processes.
- **Sessions**: `express-session` with a SQLite-backed store (`better-sqlite3-session-store`), replacing
  Flask's signed-cookie sessions. CSRF tokens are still per-session random tokens checked on every POST.
- **Images**: `sharp` instead of Pillow for validating, resizing and re-encoding uploads.
- **Markdown**: `markdown-it` + `sanitize-html` instead of Python-Markdown + `bleach`. The `!!! answer
  "Title"` admonition syntax and the `[[chart]]` marker are supported via the same preprocessing approach.
- **Email notification** for new contact messages (optional, via SMTP) was not ported — messages are
  always stored and visible in the admin inbox regardless. Add your own `nodemailer` call in
  `app.js`'s `notifyEmail()` if you want it.

## Before you launch

Same checklist as any fresh deployment of this site:

1. **Legal pages** (`/privacy/`, `/terms/`) are drafts, not legal advice — have them reviewed.
2. **Contact email**: none is published by default. Add yours in Settings if you want it shown.
3. **Analytics**: add your GA4 ID and Search Console token in Settings, then submit `sitemap.xml`.
4. **Authorship**: pages credit "KJ to Cal Editorial Team" by default; update per-page author fields and
   `/about/` if real named authors will be credited.
5. **HTTPS is required in production** — cookies are `Secure`. Hostinger's one-click SSL or `certbot`
   both work fine with this setup.
6. **On Hostinger Business hosting specifically**: decide whether to set up object storage (Part B of
   the Hostinger guide above) before you start adding real content through the admin panel. It's a
   five-minute step either way, but doing it first means you never have to think about redeploy risk.

## Project layout

```
app.js                      Express app: middleware, public routes, rendering, error handlers
manage.js                   CLI: create-admin, reset-password, list-users, check
src/lib/                    converter.js, db.js, content.js, auth.js, core.js, seed.js, adminUi.js,
                             storage.js (optional S3-compatible storage; everything else works without it)
src/routes/admin.js         the entire admin CMS (one router, mirrors admin.py)
src/data/                   seed-content.json (page copy, exported once from the tested Python build),
                             keywords.tsv (your keyword list)
views/                      page.ejs, value.ejs, 404.ejs, error.ejs, partials/ (public site)
views/admin/                one .ejs per admin screen, _header.ejs/_footer.ejs (shared chrome)
public/                     css/, js/, fonts/, img/ — same site.css/site.js/admin.css/admin.js as the
                             Python build (framework-agnostic, copied over unchanged)
tests/                      crawl.js, keywords.js, concurrent_boot.js (+ _boot_worker.js helper)
deploy/                     nginx.conf, kjtocal.service (systemd), ecosystem.config.js (PM2)
Dockerfile, Procfile, .env.example
```
