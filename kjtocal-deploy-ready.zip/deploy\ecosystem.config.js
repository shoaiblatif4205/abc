// PM2 process file, an alternative to systemd. Usage: pm2 start deploy/ecosystem.config.js
module.exports = {
  apps: [{
    name: "kjtocal",
    script: "app.js",
    cwd: "/srv/kjtocal",
    instances: 1, // keep at 1: SQLite + the file-based session store are not built for PM2 cluster mode
    exec_mode: "fork",
    env: { KJ_ENV: "production", PORT: 3000 },
    autorestart: true,
  }],
};
