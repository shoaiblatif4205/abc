"use strict";
/** Crawl the whole public site via a live HTTP server and assert quality rules. Mirrors tests/crawl.py. */
const http = require("http");
const { URL } = require("url");

const BASE = process.env.BASE_URL || "http://localhost:5091";
const problems = [];
const bad = (m) => problems.push(m);

function get(p, extraHeaders) {
  return new Promise((resolve) => {
    const u = new URL(p, BASE);
    const req = http.request(u, { method: "GET", headers: extraHeaders || {} }, (res) => {
      let data = "";
      res.on("data", (c) => (data += c));
      res.on("end", () => resolve({ status: res.statusCode, headers: res.headers, body: data }));
    });
    req.on("error", () => resolve({ status: 0, headers: {}, body: "" }));
    req.end();
  });
}

function extractAll(html) {
  const h1 = (html.match(/<h1[ >]/g) || []).length;
  const title = (/<title>([\s\S]*?)<\/title>/.exec(html) || [, ""])[1].trim();
  const desc = (/<meta name="description" content="([^"]*)"/.exec(html) || [, ""])[1];
  const canon = (/<link rel="canonical" href="([^"]*)"/.exec(html) || [, null])[1];
  const links = Array.from(html.matchAll(/<a [^>]*href="([^"]*)"/g)).map((m) => m[1]);
  const ldBlobs = Array.from(html.matchAll(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/g)).map((m) => m[1]);
  const ids = new Set(Array.from(html.matchAll(/\sid="([^"]+)"/g)).map((m) => m[1]));
  const imgsNoAlt = (html.match(/<img(?![^>]*\balt=)[^>]*>/g) || []).length;
  return { h1, title, desc, canon, links, ldBlobs, ids, imgsNoAlt };
}

async function main() {
  const sm = await get("/sitemap.xml");
  if (sm.status !== 200) { console.log("FATAL: sitemap not 200"); process.exit(1); }
  const paths = Array.from(sm.body.matchAll(/<loc>(.*?)<\/loc>/g)).map((m) => m[1].replace(/^https:\/\/kjtocal\.org/, ""));
  console.log("sitemap urls:", paths.length);
  if (new Set(paths).size !== paths.length) bad("duplicate sitemap urls");

  const allPaths = new Set(paths);
  const titles = {}, descs = {}, pagesHtml = {};
  for (const p of paths) {
    const r = await get(p);
    if (r.status !== 200) { bad(`${p}: status ${r.status}`); continue; }
    pagesHtml[p] = r.body;
    const x = extractAll(r.body);
    if (x.h1 !== 1) bad(`${p}: ${x.h1} h1 tags`);
    (titles[x.title] = titles[x.title] || []).push(p);
    (descs[x.desc] = descs[x.desc] || []).push(p);
    if (x.title.length > 62) bad(`${p}: title ${x.title.length} chars: ${x.title}`);
    if (!x.desc || x.desc.length > 160 || x.desc.length < 100) bad(`${p}: meta desc length ${x.desc.length}`);
    if (x.canon !== "https://kjtocal.org" + p) bad(`${p}: canonical ${x.canon}`);
    for (const blob of x.ldBlobs) {
      try { JSON.parse(blob); } catch (e) { bad(`${p}: invalid JSON-LD ${e.message}`); }
    }
    if (!x.ldBlobs.length) bad(`${p}: no JSON-LD`);
    if (x.imgsNoAlt) bad(`${p}: img without alt`);
    for (const h of x.links) {
      if (h.startsWith("/") && !h.startsWith("//")) {
        const base = h.replace(/[?#].*$/, "");
        if (base.startsWith("/img/") || base.startsWith("/css/") || base.startsWith("/js/") || base.startsWith("/fonts/") || base.startsWith("/favicon")) continue;
        if (!allPaths.has(base)) {
          const check = await get(base);
          if (check.status !== 200) bad(`${p}: broken link ${h}`);
        }
      }
      if (h.startsWith("#") && h.length > 1 && !x.ids.has(h.slice(1))) bad(`${p}: dead anchor ${h}`);
    }
  }
  for (const [t, ps] of Object.entries(titles)) if (ps.length > 1) bad(`duplicate title ${JSON.stringify(t)}: ${ps}`);
  for (const [d, ps] of Object.entries(descs)) if (ps.length > 1) bad(`duplicate description: ${ps}`);

  // misc endpoints
  const robots = await get("/robots.txt");
  if (robots.status !== 200 || !robots.body.includes("Sitemap: https://kjtocal.org/sitemap.xml")) bad("robots.txt wrong");
  if ((await get("/does-not-exist/")).status !== 404) bad("404 page wrong status");
  if ((await get("/convert/999-kj-to-calories/")).status !== 404) bad("out-of-range value page should 404");
  if ((await get("/convert/abc/")).status !== 404) bad("bad slug should 404");
  const r1 = await get("/calories-to-kj");
  if (r1.status !== 301 || !r1.headers.location.endsWith("/calories-to-kj/")) bad(`trailing-slash redirect wrong: ${r1.status} ${r1.headers.location}`);
  const r2 = await get("/CALORIES-TO-KJ/");
  if (![301, 308].includes(r2.status)) bad(`case-normalise redirect wrong: ${r2.status}`);
  if ((await get("/favicon.ico")).status !== 200) bad("favicon missing");
  if ((await get("/css/site.css")).status !== 200) bad("site.css missing");
  if ((await get("/js/site.js")).status !== 200) bad("site.js missing");
  const home = await get("/");
  if (!home.headers.etag) bad("home missing etag");
  const cond = await get("/", { "If-None-Match": home.headers.etag });
  if (cond.status !== 304) bad(`conditional GET should 304, got ${cond.status}`);

  function words(h) {
    h = h.replace(/<(script|style)[^>]*>[\s\S]*?<\/\1>/g, " ").replace(/<[^>]+>/g, " ");
    return h.split(/\s+/).filter(Boolean).length;
  }
  const low = Object.entries(pagesHtml).filter(([p, h]) => words(h) < 350 && !p.startsWith("/convert/")).map(([p, h]) => [p, words(h)]);
  console.log("pages under 350 rendered words:", JSON.stringify(low));

  console.log("PROBLEMS:", problems.length);
  problems.forEach((p) => console.log(" -", p));
  process.exit(problems.length ? 1 : 0);
}

main();
